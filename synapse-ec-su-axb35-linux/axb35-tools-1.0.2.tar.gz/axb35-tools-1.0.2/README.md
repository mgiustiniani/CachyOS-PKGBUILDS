# ec-su_axb35-linux
Linux driver for the embedded controller on the Sixunited AXB35-02 board.

Vendors using that board:
  - GMKtec EVO-X2
  - Bosgame M5
  - FEVM FA-EX9
  - Peladn YO1
  - NIMO AI MiniPC

An update to date list can be found [here](https://strixhalo-homelab.d7.wtf/Hardware/Boards/Sixunited-AXB35)

For more details, please have a look at the desevens wiki: https://strixhalo-homelab.d7.wtf/Guides/Power-Mode-and-Fan-Control

# Build instructions
Install the header package for the target kernel, then run:

```sh
make
sudo make install
sudo modprobe ec_su_axb35
```

The kernel Makefile automatically selects LLVM for kernels built with Clang. To
build for an installed kernel other than the currently running one, pass its
release explicitly:

```sh
make KERNELRELEASE=7.1.3-2-cachyos
```

On unsupported hardware the kernel module exits with `ENODEV` without accessing
the embedded controller.

# Temperature policy monitor

The monitor is read-only by default. Run it with `-a` as root to program the
hardware temperature curves and keep Z13 PPT limits aligned with the active
profile:

```sh
sudo axb35-monitor -a
```

Z13 stock limits are quiet=40 W, balanced=52 W, and performance=70 W. Changing
the profile through `powerprofilesctl` updates `platform_profile` but not the
ASUS PPT sysfs values; control mode reconciles that mismatch while it runs.

Z13 does not expose the native AXB35 fan `level` register. The monitor therefore
shows a normalized 0-5 level derived from the active temperature curve and its
estimated PWM percentage. It is reported only while the fan is in custom mode.

# CachyOS package

```sh
cd pkgs/cachyos
makepkg --cleanbuild
sudo pacman -U axb35-tools-*.pkg.tar.zst
```

# Devices
```
# Fan devices
/sys/class/ec_su_axb35/fan1/                    - CPU fan 1
/sys/class/ec_su_axb35/fan2/                    - CPU fan 2
/sys/class/ec_su_axb35/fan3/                    - System fan
/sys/class/ec_su_axb35/fanX/rpm            (RO) - current speed in rpm
/sys/class/ec_su_axb35/fanX/mode           (RW) - [auto, fixed, curve]
/sys/class/ec_su_axb35/fanX/level          (RW) - [0-5] (0=0%, 1=20%, ..., 5=100%)
/sys/class/ec_su_axb35/fanX/rampup_curve   (RW) - 5 values (°C thresholds for level 1-5)
/sys/class/ec_su_axb35/fanX/rampdown_curve (RW) - 5 values (°C thresholds for level 1-5)

# Temperature device
/sys/class/ec_su_axb35/temp1/                   - CPU temperature in °C
/sys/class/ec_su_axb35/temp1/temp          (RO) - current
/sys/class/ec_su_axb35/temp1/min           (RO) - min temp measured since dirver load
/sys/class/ec_su_axb35/temp1/max           (RO) - amx temp measured since driver load

# APU device
/sys/class/ec_su_axb35/apu/power_mode      (RW) - [quiet, balanced, performance]
```

# Python GUI app (needs root to write to /sys/class/ec_su_axb35/*)
to test:
python ./ec-su_axb35-linux-gui.py

to install:
sudo install -m 755 ec-su_axb35-linux-gui.py /usr/local/bin/ec-su_axb35-linux-gui
cp ec-fan-control.desktop ~/.local/share/applications/