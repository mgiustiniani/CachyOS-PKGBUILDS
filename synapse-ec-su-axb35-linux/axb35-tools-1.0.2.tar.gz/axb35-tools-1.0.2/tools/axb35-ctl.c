/*
 * axb35-ctl — Multi-platform CLI tool for system control
 *
 * Supports:
 *   - AXB35 (Sixunited AXB35-02 EC): 3 fans, APU power mode, EC temp
 *   - Z13 ROG Flow (ASUS WMI EC): 2 fans, platform_profile, PPT, battery
 *
 * Platform auto-detected via DMI (same as axb35-monitor)
 * Compile with PLATFORM=axb35, PLATFORM=z13, or PLATFORM=auto (default)
 *
 * Copyright (C) 2025  axb35-tools contributors
 * SPDX-License-Identifier: GPL-2.0-only
 */

#define _POSIX_C_SOURCE 200809L
#include "sysfs-helpers.h"
#include "platform-policy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <ctype.h>
#include <unistd.h>
#include <libgen.h>
#include <pthread.h>
#include <time.h>
#include <signal.h>

/* ------------------------------------------------------------------ */
/* Platform detection (same as monitor)                                */
/* ------------------------------------------------------------------ */
#define PLAT_AXB35 0
#define PLAT_Z13   1

static int detect_platform(void)
{
#if defined(PLATFORM_AXB35)
    return PLAT_AXB35;
#elif defined(PLATFORM_Z13)
    return PLAT_Z13;
#else
    FILE *f = fopen("/sys/class/dmi/id/product_name", "r");
    if (!f) return -1;
    char buf[128]; buf[0] = 0;
    fgets(buf, sizeof(buf), f); fclose(f);
    char *nl = strchr(buf, '\n'); if (nl) *nl = 0;
    if (strstr(buf, "ROG") || strstr(buf, "GZ302") || strstr(buf, "GZ301")) return PLAT_Z13;
    if (strstr(buf, "BeyondMax") || strstr(buf, "Bosgame")) return PLAT_AXB35;
    f = fopen("/sys/class/dmi/id/sys_vendor", "r");
    if (!f) return -1;
    buf[0] = 0;
    fgets(buf, sizeof(buf), f); fclose(f);
    nl = strchr(buf, '\n'); if (nl) *nl = 0;
    if (strstr(buf, "Bosgame")) return PLAT_AXB35;
    if (strstr(buf, "ASUS")) return PLAT_Z13;
    return -1;
#endif
}

/* ------------------------------------------------------------------ */
/* Platform ops — each command is a function pointer                   */
/* ------------------------------------------------------------------ */
typedef struct {
    const char *name;
    int  fan_count;
    int  (*cmd_get)(int argc, char **argv);
    int  (*cmd_set)(int argc, char **argv);
    int  (*cmd_apply)(int argc, char **argv);
    int  (*cmd_save)(int argc, char **argv);
    int  (*cmd_load)(int argc, char **argv);
    int  (*cmd_telemetry)(int argc, char **argv);
    int  (*cmd_daemon)(int argc, char **argv);
} PlatformCLI;

static PlatformCLI *active_platform = NULL;

/* ------------------------------------------------------------------ */
/* Forward declarations                                               */
/* ------------------------------------------------------------------ */
static int axb35_cmd_get(int, char **);
static int axb35_cmd_set(int, char **);
static int axb35_cmd_apply(int, char **);
static int axb35_cmd_save(int, char **);
static int axb35_cmd_load(int, char **);
static int axb35_cmd_telemetry(int, char **);
static int axb35_cmd_daemon(int, char **);

static int z13_cmd_get(int, char **);
static int z13_cmd_set(int, char **);
static int z13_cmd_load(int, char **);
static int z13_cmd_telemetry(int, char **);
static int z13_cmd_daemon(int, char **);

/* Z13 apply/save are shared fallbacks */
static int z13_cmd_apply(int argc, char **argv)
{
    char profile[64];
    (void)argc;
    (void)argv;

    printf("Applying Z13 temperature curves...\n");
    if (z13_apply_temperature_policy() != 0) {
        fprintf(stderr, "Failed to apply the Z13 temperature policy.\n");
        return 1;
    }

    if (sysfs_read("/sys/firmware/acpi/platform_profile", profile,
                   sizeof(profile)) == 0) {
        printf("Done: fans in custom curve mode, profile %s, PPT %ldW.\n",
               profile, z13_profile_power_limit(profile));
    } else {
        printf("Done: fans in custom curve mode.\n");
    }
    return 0;
}
static int z13_cmd_save(int argc, char **argv)  { (void)argc; (void)argv; printf("Save not implemented for Z13\n"); return 1; }

/* ------------------------------------------------------------------ */
/* Platform ops tables                                                 */
/* ------------------------------------------------------------------ */
static PlatformCLI axb35_ops = {
    .name         = "AXB35",
    .fan_count    = 3,
    .cmd_get      = axb35_cmd_get,
    .cmd_set      = axb35_cmd_set,
    .cmd_apply    = axb35_cmd_apply,
    .cmd_save     = axb35_cmd_save,
    .cmd_load     = axb35_cmd_load,
    .cmd_telemetry = axb35_cmd_telemetry,
    .cmd_daemon   = axb35_cmd_daemon,
};

static PlatformCLI z13_ops = {
    .name         = "Z13",
    .fan_count    = 2,
    .cmd_get      = z13_cmd_get,
    .cmd_set      = z13_cmd_set,
    .cmd_apply    = z13_cmd_apply,
    .cmd_save     = z13_cmd_save,
    .cmd_load     = z13_cmd_load,
    .cmd_telemetry = z13_cmd_telemetry,
    .cmd_daemon   = z13_cmd_daemon,
};

/* ------------------------------------------------------------------ */
/* Common usage                                                        */
/* ------------------------------------------------------------------ */
static void usage(const char *prog)
{
    const char *pname = active_platform ? active_platform->name : "auto";

    fprintf(stderr,
        "Usage: %s <command> [args]\n"
        "\n"
        "Platform: %s (detected via DMI)\n"
        "\n"
        "Commands:\n"
        "  get [all|fan<N>|temp|apu|mem|gpu|battery|tdp|profile]   Read current state\n"
        "  set fan <num> mode <auto|fixed|curve>       Set fan mode (AXB35)\n"
        "  set fan <num> level <0-5>                   Set fan level (AXB35)\n"
        "  set fan <num> rampup <c1,c2,c3,c4,c5>       Set rampup curve (AXB35)\n"
        "  set fan <num> rampdown <c1,c2,c3,c4,c5>     Set rampdown curve (AXB35)\n"
        "  set fan <num> curve <16 vals>               Set 8-point fan curve (Z13)\n"
        "  set fan <num> enable <0|1|2>                Set fan mode (Z13)\n"
        "  set apu <quiet|balanced|performance>        Set APU power mode (AXB35)\n"
        "  set profile <quiet|balanced|performance>    Set platform profile (Z13)\n"
        "  set ppt_fppt|ppt_pl1_spl|ppt_pl2_sppt <val> Set PPT limits (Z13)\n"
        "  set charge_mode <0|1>                       Set battery charge mode (Z13)\n"
        "  set boot_sound <0|1>                        Set boot sound (Z13)\n"
        "  set panel_od <0|1>                          Set panel overdrive (Z13)\n"
        "  apply                                        Apply defaults (AXB35)\n"
        "  save [<path>]                                Save config to JSON\n"
        "  load <path>                                  Load and apply from JSON\n"
        "  telemetry start|stop|dump                   Telemetry collection\n"
        "  daemon start|stop|status                    Background daemon\n"
        "\n"
        "Examples:\n"
        "  %s get all\n"
        "  %s set fan 1 mode curve\n"
        "  %s set fan 1 rampup 60,70,83,95,97\n"
        "  %s set profile performance\n"
        "  %s daemon start\n",
        prog, pname, prog, prog, prog, prog, prog
    );
}

/* ------------------------------------------------------------------ */
/* Main dispatch                                                       */
/* ------------------------------------------------------------------ */
int main(int argc, char **argv)
{
    /* Detect platform */
    int plat = detect_platform();
    if (plat < 0) {
        fprintf(stderr, "Unknown platform — cannot determine hardware\n");
        fprintf(stderr, "Use PLATFORM=axb35 or PLATFORM=z13 to force a platform\n");
        return 1;
    }

    if (plat == PLAT_AXB35)
        active_platform = &axb35_ops;
    else
        active_platform = &z13_ops;

    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "get") == 0)
        return active_platform->cmd_get(argc - 2, argv + 2);
    else if (strcmp(argv[1], "set") == 0)
        return active_platform->cmd_set(argc - 2, argv + 2);
    else if (strcmp(argv[1], "apply") == 0)
        return active_platform->cmd_apply(argc - 2, argv + 2);
    else if (strcmp(argv[1], "save") == 0)
        return active_platform->cmd_save(argc - 2, argv + 2);
    else if (strcmp(argv[1], "load") == 0)
        return active_platform->cmd_load(argc - 2, argv + 2);
    else if (strcmp(argv[1], "telemetry") == 0)
        return active_platform->cmd_telemetry(argc - 2, argv + 2);
    else if (strcmp(argv[1], "daemon") == 0)
        return active_platform->cmd_daemon(argc - 2, argv + 2);
    else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
        usage(argv[0]);
        return 0;
    } else {
        fprintf(stderr, "Unknown command: %s\n", argv[1]);
        usage(argv[0]);
        return 1;
    }
}

/* ================================================================== */
/*                        AXB35 HANDLERS                               */
/* ================================================================== */

/* Default config path */
#define CONFIG_DEFAULT "/etc/axb35-config.json"

/* Default curves (rampup, rampdown) — identiche per tutte le ventole */
/* ------------------------------------------------------------------ */
/* AXB35 GET                                                           */
/* ------------------------------------------------------------------ */

static void axb35_get_all_json(void)
{
    char val[256];
    printf("{\n");
    for (int i = 1; i <= 3; i++) {
        char path[256], ru[256] = "", rd[256] = "";
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rpm", i);
        long rpm = sysfs_read_long(path);
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", i);
        sysfs_read(path, val, sizeof(val));
        char *mode = val[0] ? val : "unknown";
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/level", i);
        long level = sysfs_read_long(path);
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampup_curve", i);
        sysfs_read(path, ru, sizeof(ru));
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampdown_curve", i);
        sysfs_read(path, rd, sizeof(rd));
        printf("  \"fan%d\": {\n", i);
        printf("    \"rpm\": %ld,\n", rpm);
        printf("    \"mode\": \"%s\",\n", mode);
        if (level >= 0) printf("    \"level\": %ld,\n", level);
        if (ru[0])      printf("    \"rampup_curve\": \"%s\",\n", ru);
        if (rd[0])      printf("    \"rampdown_curve\": \"%s\"\n", rd);
        else            printf("    \"rampdown_curve\": \"\"\n");
        printf("  },\n");
    }
    snprintf(val, sizeof(val), AXB35_PATH "/apu/power_mode");
    char apu[64] = "";
    sysfs_read(val, apu, sizeof(apu));
    printf("  \"apu_power_mode\": \"%s\",\n", apu[0] ? apu : "unknown");
    long temp = sysfs_read_long(AXB35_PATH "/temp1/temp");
    printf("  \"cpu_temp\": %ld,\n", temp);
    long tmin = sysfs_read_long(AXB35_PATH "/temp1/min");
    printf("  \"cpu_temp_min\": %ld,\n", tmin);
    long tmax = sysfs_read_long(AXB35_PATH "/temp1/max");
    printf("  \"cpu_temp_max\": %ld,\n", tmax);
    long vram_total = sysfs_read_long(DRM_PATH "/mem_info_vram_total");
    long vram_used  = sysfs_read_long(DRM_PATH "/mem_info_vram_used");
    printf("  \"vram_total\": %ld,\n", vram_total);
    printf("  \"vram_used\": %ld,\n", vram_used);
    long gpu_power = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    printf("  \"gpu_power_watts\": %.2f,\n", gpu_power / 1000000.0);
    long gpu_freq  = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    printf("  \"gpu_freq\": %ld,\n", gpu_freq);
    long gpu_temp  = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
    printf("  \"gpu_temp_c\": %ld,\n", gpu_temp / 1000);
    /* TDP derived from APU mode */
    char apu_val[64] = "";
    sysfs_read(AXB35_PATH "/apu/power_mode", apu_val, sizeof(apu_val));
    const char *tdp_str;
    if (strcmp(apu_val, "quiet") == 0) tdp_str = "65";
    else if (strcmp(apu_val, "balanced") == 0) tdp_str = "85";
    else if (strcmp(apu_val, "performance") == 0) tdp_str = "120";
    else tdp_str = "-1";
    printf("  \"tdp_watts\": %s,\n", tdp_str);
    long cpu_temp = sysfs_read_hwmon_long("k10temp", "/temp1_input");
    printf("  \"cpu_temp_raw\": %ld\n", cpu_temp);
    printf("}\n");
}

static int axb35_cmd_get(int argc, char **argv)
{
    const char *sub = (argc > 0) ? argv[0] : "all";

    if (strcmp(sub, "all") == 0 || strcmp(sub, "full") == 0) {
        axb35_get_all_json();
        return 0;
    }

    if (strncmp(sub, "fan", 3) == 0) {
        int fan = atoi(sub + 3);
        if (fan < 1 || fan > 3) {
            fprintf(stderr, "Invalid fan: %s (use fan1..fan3)\n", sub);
            return 1;
        }
        char path[256], val[64];
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rpm", fan);
        long rpm = sysfs_read_long(path);
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", fan);
        sysfs_read(path, val, sizeof(val));
        printf("fan%d: rpm=%ld mode=%s\n", fan, rpm, val);
        return 0;
    }

    if (strcmp(sub, "apu") == 0) {
        char val[64] = "";
        sysfs_read(AXB35_PATH "/apu/power_mode", val, sizeof(val));
        printf("apu_power_mode: %s\n", val[0] ? val : "unknown");
        return 0;
    }

    if (strcmp(sub, "temp") == 0) {
        long t = sysfs_read_long(AXB35_PATH "/temp1/temp");
        printf("cpu_temp: %ld\n", t);
        return 0;
    }

    if (strcmp(sub, "mem") == 0) {
        long vram_t = sysfs_read_long(DRM_PATH "/mem_info_vram_total");
        long vram_u = sysfs_read_long(DRM_PATH "/mem_info_vram_used");
        long vis_t  = sysfs_read_long(DRM_PATH "/mem_info_vis_vram_total");
        long vis_u  = sysfs_read_long(DRM_PATH "/mem_info_vis_vram_used");
        long gtt_t  = sysfs_read_long(DRM_PATH "/mem_info_gtt_total");
        long gtt_u  = sysfs_read_long(DRM_PATH "/mem_info_gtt_used");
        printf("vram:     total=%ld used=%ld\n", vram_t, vram_u);
        printf("vis_vram: total=%ld used=%ld\n", vis_t, vis_u);
        printf("gtt:      total=%ld used=%ld\n", gtt_t, gtt_u);
        return 0;
    }

    if (strcmp(sub, "gpu") == 0) {
        long p = sysfs_read_hwmon_long("amdgpu", "/power1_average");
        long f = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
        long t = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
        printf("gpu_power: %.2f W\n", p / 1000000.0);
        printf("gpu_freq: %ld Hz\n", f);
        printf("gpu_temp: %ld °C\n", t / 1000);
        return 0;
    }

    if (strcmp(sub, "battery") == 0) {
        const char *glob = "/sys/class/power_supply/BAT0/capacity";
        FILE *f = fopen(glob, "r");
        if (f) { char buf[32]; buf[0]=0; fgets(buf, sizeof(buf), f); fclose(f);
            printf("battery_capacity: %s%%", buf); }
        else { printf("battery: N/A (no battery)"); }
        printf("\n");
        return 0;
    }

    if (strcmp(sub, "tdp") == 0) {
        char val[64] = "";
        sysfs_read(AXB35_PATH "/apu/power_mode", val, sizeof(val));
        const char *tdp = "?";
        if (strcmp(val, "quiet") == 0)       tdp = "65 W";
        else if (strcmp(val, "balanced") == 0)    tdp = "85 W";
        else if (strcmp(val, "performance") == 0) tdp = "120 W";
        printf("tdp: %s (from APU mode: %s)\n", tdp, val[0] ? val : "unknown");
        return 0;
    }

    if (strcmp(sub, "profile") == 0) {
        const char *pp = "/sys/firmware/acpi/platform_profile";
        FILE *f = fopen(pp, "r");
        char buf[64];
        if (f) { buf[0]=0; fgets(buf, sizeof(buf), f); fclose(f);
            char *nl = strchr(buf, '\n'); if (nl) *nl = 0;
            printf("platform_profile: %s\n", buf); }
        else {
            char val[64] = "";
            sysfs_read(AXB35_PATH "/apu/power_mode", val, sizeof(val));
            if (val[0])
                printf("platform_profile: %s (from APU mode)\n", val);
            else
                printf("platform_profile: N/A\n");
        }
        return 0;
    }

    fprintf(stderr, "Unknown get target: %s (use all, fan<N>, apu, temp, mem, gpu, battery, tdp, profile)\n", sub);
    return 1;
}

/* ------------------------------------------------------------------ */
/* AXB35 SET                                                           */
/* ------------------------------------------------------------------ */

static int parse_curve(const char *str, int *vals, int n)
{
    char buf[256];
    strncpy(buf, str, sizeof(buf) - 1);
    buf[sizeof(buf) - 1] = '\0';
    char *save = NULL;
    char *tok = strtok_r(buf, ",", &save);
    int i = 0;
    while (tok && i < n) {
        vals[i] = atoi(tok);
        if (vals[i] < 0 || vals[i] > 100) {
            fprintf(stderr, "Curve value %d out of range (0-100)\n", vals[i]);
            return -1;
        }
        i++;
        tok = strtok_r(NULL, ",", &save);
    }
    if (i != n) {
        fprintf(stderr, "Expected %d curve values, got %d\n", n, i);
        return -1;
    }
    return 0;
}

static int axb35_cmd_set(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "Usage: set <type> <args...>\n");
        return 1;
    }

    if (strcmp(argv[0], "fan") == 0 && argc >= 4) {
        int fan = atoi(argv[1]);
        if (fan < 1 || fan > 3) {
            fprintf(stderr, "Invalid fan number: %d\n", fan);
            return 1;
        }

        if (strcmp(argv[2], "mode") == 0) {
            char path[256];
            snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", fan);
            if (sysfs_write(path, argv[3]) != 0) return 1;
            printf("fan%d mode set to %s\n", fan, argv[3]);
            return 0;
        }

        if (strcmp(argv[2], "level") == 0) {
            int level = atoi(argv[3]);
            if (level < 0 || level > 5) {
                fprintf(stderr, "Level must be 0-5\n");
                return 1;
            }
            char path[256];
            snprintf(path, sizeof(path), AXB35_PATH "/fan%d/level", fan);
            if (sysfs_write(path, argv[3]) != 0) return 1;
            printf("fan%d level set to %s\n", fan, argv[3]);
            return 0;
        }

        if (strcmp(argv[2], "rampup") == 0 && argc >= 4) {
            int vals[5];
            if (parse_curve(argv[3], vals, 5) != 0) return 1;
            char path[256], buf[64];
            snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampup_curve", fan);
            snprintf(buf, sizeof(buf), "%d,%d,%d,%d,%d",
                     vals[0], vals[1], vals[2], vals[3], vals[4]);
            if (sysfs_write(path, buf) != 0) return 1;
            printf("fan%d rampup_curve set to %s\n", fan, buf);
            return 0;
        }

        if (strcmp(argv[2], "rampdown") == 0 && argc >= 4) {
            int vals[5];
            if (parse_curve(argv[3], vals, 5) != 0) return 1;
            char path[256], buf[64];
            snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampdown_curve", fan);
            snprintf(buf, sizeof(buf), "%d,%d,%d,%d,%d",
                     vals[0], vals[1], vals[2], vals[3], vals[4]);
            if (sysfs_write(path, buf) != 0) return 1;
            printf("fan%d rampdown_curve set to %s\n", fan, buf);
            return 0;
        }

        fprintf(stderr, "Unknown fan subcommand: %s\n", argv[2]);
        return 1;
    }

    if (strcmp(argv[0], "apu") == 0 && argc >= 2) {
        if (strcmp(argv[1], "quiet") != 0 &&
            strcmp(argv[1], "balanced") != 0 &&
            strcmp(argv[1], "performance") != 0) {
            fprintf(stderr, "Invalid APU mode: %s\n", argv[1]);
            return 1;
        }
        char path[256];
        snprintf(path, sizeof(path), AXB35_PATH "/apu/power_mode");
        if (sysfs_write(path, argv[1]) != 0) return 1;
        printf("APU power mode set to %s\n", argv[1]);
        return 0;
    }

    fprintf(stderr, "Unknown set target: %s\n", argv[0]);
    return 1;
}

/* ------------------------------------------------------------------ */
/* AXB35 APPLY                                                         */
/* ------------------------------------------------------------------ */

static int axb35_cmd_apply(int argc, char **argv)
{
    (void)argc; (void)argv;
    char path[256];
    snprintf(path, sizeof(path), "%s", CONFIG_DEFAULT);
    FILE *fp = fopen(path, "r");
    if (fp) { fclose(fp); }
    printf("Applying default curves...\n");
    if (axb35_apply_temperature_policy() != 0) {
        fprintf(stderr, "Failed to apply one or more AXB35 settings.\n");
        return 1;
    }
    printf("Done: all fans in curve mode; the current APU mode was preserved.\n");
    return 0;
}

/* ------------------------------------------------------------------ */
/* AXB35 SAVE / LOAD                                                   */
/* ------------------------------------------------------------------ */

static void axb35_save_json(const char *path)
{
    char val[256];
    FILE *fp = fopen(path, "w");
    if (!fp) {
        fprintf(stderr, "Can't write %s: %s\n", path, strerror(errno));
        return;
    }
    fprintf(fp, "{\n");
    for (int i = 1; i <= 3; i++) {
        char ru[256] = "", rd[256] = "";
        snprintf(val, sizeof(val), AXB35_PATH "/fan%d/mode", i);
        char mode[64] = "";
        sysfs_read(val, mode, sizeof(mode));
        snprintf(val, sizeof(val), AXB35_PATH "/fan%d/level", i);
        long level = sysfs_read_long(val);
        snprintf(val, sizeof(val), AXB35_PATH "/fan%d/rampup_curve", i);
        sysfs_read(val, ru, sizeof(ru));
        snprintf(val, sizeof(val), AXB35_PATH "/fan%d/rampdown_curve", i);
        sysfs_read(val, rd, sizeof(rd));
        fprintf(fp, "  \"fan%d\": {\n", i);
        fprintf(fp, "    \"mode\": \"%s\"", mode);
        if (level >= 0) fprintf(fp, ",\n    \"level\": %ld", level);
        if (ru[0])      fprintf(fp, ",\n    \"rampup_curve\": \"%s\"", ru);
        if (rd[0])      fprintf(fp, ",\n    \"rampdown_curve\": \"%s\"", rd);
        fprintf(fp, "\n  },\n");
    }
    char apu[64] = "";
    sysfs_read(AXB35_PATH "/apu/power_mode", apu, sizeof(apu));
    fprintf(fp, "  \"apu_power_mode\": \"%s\"\n", apu[0] ? apu : "balanced");
    fprintf(fp, "}\n");
    fclose(fp);
    printf("Saved to %s\n", path);
}

static int axb35_cmd_save(int argc, char **argv)
{
    const char *path = (argc > 0) ? argv[0] : CONFIG_DEFAULT;
    axb35_save_json(path);
    return 0;
}

static int axb35_cmd_load(int argc, char **argv)
{
    if (argc < 1) {
        fprintf(stderr, "Usage: load <path>\n");
        return 1;
    }
    FILE *fp = fopen(argv[0], "r");
    if (!fp) {
        fprintf(stderr, "Can't open %s: %s\n", argv[0], strerror(errno));
        return 1;
    }
    fseek(fp, 0, SEEK_END);
    long fsz = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *data = malloc((size_t)(fsz + 1));
    if (!data) { fclose(fp); fprintf(stderr, "Out of memory\n"); return 1; }
    size_t n = fread(data, 1, fsz, fp);
    data[n] = '\0';
    fclose(fp);

    for (int i = 1; i <= 3; i++) {
        char pat[128], path[256];
        snprintf(pat, sizeof(pat), "\"fan%d\"", i);
        char *found = strstr(data, pat);
        if (!found) continue;
        char *mptr = strstr(found, "\"mode\"");
        if (mptr) {
            char *vstart = strchr(mptr, ':');
            if (vstart) {
                while (*vstart && *vstart != '\"') vstart++;
                if (*vstart) {
                    vstart++;
                    char *vend = strchr(vstart, '\"');
                    if (vend) {
                        *vend = '\0';
                        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", i);
                        sysfs_write(path, vstart);
                        printf("fan%d mode: %s\n", i, vstart);
                        *vend = '\"';
                    }
                }
            }
        }
        char *lptr = strstr(found, "\"level\"");
        if (lptr) {
            char *vstart = strchr(lptr, ':');
            if (vstart) {
                vstart++;
                while (*vstart == ' ' || *vstart == '\n') vstart++;
                char *vend = vstart;
                while (*vend && *vend != ',' && *vend != '\n' && *vend != '}') vend++;
                char tmp = *vend;
                *vend = '\0';
                snprintf(path, sizeof(path), AXB35_PATH "/fan%d/level", i);
                sysfs_write(path, vstart);
                printf("fan%d level: %s\n", i, vstart);
                *vend = tmp;
            }
        }
        char *rptr = strstr(found, "\"rampup_curve\"");
        if (rptr) {
            char *vstart = strchr(rptr, ':');
            if (vstart) {
                while (*vstart && *vstart != '\"') vstart++;
                if (*vstart) {
                    vstart++;
                    char *vend = strchr(vstart, '\"');
                    if (vend) {
                        *vend = '\0';
                        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampup_curve", i);
                        sysfs_write(path, vstart);
                        printf("fan%d rampup_curve: %s\n", i, vstart);
                        *vend = '\"';
                    }
                }
            }
        }
        rptr = strstr(found, "\"rampdown_curve\"");
        if (rptr) {
            char *vstart = strchr(rptr, ':');
            if (vstart) {
                while (*vstart && *vstart != '\"') vstart++;
                if (*vstart) {
                    vstart++;
                    char *vend = strchr(vstart, '\"');
                    if (vend) {
                        *vend = '\0';
                        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampdown_curve", i);
                        sysfs_write(path, vstart);
                        printf("fan%d rampdown_curve: %s\n", i, vstart);
                        *vend = '\"';
                    }
                }
            }
        }
    }
    char *aptr = strstr(data, "\"apu_power_mode\"");
    if (aptr) {
        char *vstart = strchr(aptr, ':');
        if (vstart) {
            while (*vstart && *vstart != '\"') vstart++;
            if (*vstart) {
                vstart++;
                char *vend = strchr(vstart, '\"');
                if (vend) {
                    *vend = '\0';
                    sysfs_write(AXB35_PATH "/apu/power_mode", vstart);
                    printf("APU power_mode: %s\n", vstart);
                    *vend = '\"';
                }
            }
        }
    }
    free(data);
    printf("Loaded config from %s\n", argv[0]);
    return 0;
}

/* ------------------------------------------------------------------ */
/* AXB35 TELEMETRY                                                     */
/* ------------------------------------------------------------------ */
#define TELEMETRY_FILE "/tmp/axb35-telemetry.json"
#define TELEMETRY_MAX 360
#define TELEMETRY_POLL_MS 1000

typedef struct {
    long ts_ms;
    long cpu_ec;
    long cpu_raw;
    long gpu_temp;
    long gpu_power;
    long gpu_freq;
    long rpm[4];
    long vram_used;
    long gtt_used;
    long mem_avail;
    char apu_mode[64];
} TelemetrySample;

static TelemetrySample ring[TELEMETRY_MAX];
static int ring_head = 0, ring_tail = 0, ring_count = 0;
static volatile int telemetry_running = 0;

static long now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long)(ts.tv_sec * 1000LL + ts.tv_nsec / 1000000LL);
}

static void ring_push(const TelemetrySample *s)
{
    int idx = ring_head;
    ring[idx] = *s;
    ring_head = (idx + 1) % TELEMETRY_MAX;
    if (ring_count >= TELEMETRY_MAX)
        ring_tail = (ring_tail + 1) % TELEMETRY_MAX;
    else
        ring_count++;
}

static void axb35_collect_sample(TelemetrySample *s)
{
    s->ts_ms = now_ms();
    s->cpu_ec   = sysfs_read_long(AXB35_PATH "/temp1/temp");
    s->cpu_raw  = sysfs_read_hwmon_long("k10temp", "/temp1_input");
    s->gpu_temp = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
    s->gpu_power = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    s->gpu_freq  = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    char p[256], val[64];
    for (int i = 1; i <= 3; i++) {
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/rpm", i);
        s->rpm[i] = sysfs_read_long(p);
    }
    s->vram_used = sysfs_read_long(DRM_PATH "/mem_info_vram_used");
    s->gtt_used  = sysfs_read_long(DRM_PATH "/mem_info_gtt_used");
    FILE *fp = fopen("/proc/meminfo", "r");
    if (fp) {
        char buf[128]; long avail = -1;
        while (fgets(buf, sizeof(buf), fp))
            if (sscanf(buf, "MemAvailable: %ld", &avail) == 1) break;
        s->mem_avail = avail;
        fclose(fp);
    } else { s->mem_avail = -1; }
    sysfs_read(AXB35_PATH "/apu/power_mode", val, sizeof(val));
    snprintf(s->apu_mode, sizeof(s->apu_mode), "%s", val[0] ? val : "unknown");
}

static pthread_t telemetry_thread;
static void *telemetry_loop(void *arg)
{
    (void)arg;
    while (telemetry_running) {
        TelemetrySample s;
        axb35_collect_sample(&s);
        ring_push(&s);
        struct timespec ts;
        ts.tv_sec = TELEMETRY_POLL_MS / 1000;
        ts.tv_nsec = (long)(TELEMETRY_POLL_MS % 1000) * 1000000L;
        nanosleep(&ts, NULL);
    }
    return NULL;
}

static void telemetry_start(void)
{
    if (telemetry_running) { printf("Telemetry: already running\n"); return; }
    telemetry_running = 1;
    ring_head = ring_tail = ring_count = 0;
    pthread_create(&telemetry_thread, NULL, telemetry_loop, NULL);
    pthread_detach(telemetry_thread);
    printf("Telemetry: started\n");
}

static void telemetry_stop(void)
{
    if (!telemetry_running) { printf("Telemetry: not running\n"); return; }
    telemetry_running = 0;
    printf("Telemetry: stopped\n");
}

static void telemetry_dump(void)
{
    FILE *fp = fopen(TELEMETRY_FILE, "r");
    if (!fp) { printf("No telemetry data found (%s)\n", TELEMETRY_FILE); return; }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) fwrite(buf, 1, n, stdout);
    fclose(fp);
}

static int axb35_cmd_telemetry(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: telemetry start|stop|dump\n"); return 1; }
    if (strcmp(argv[0], "start") == 0) { telemetry_start(); return 0; }
    if (strcmp(argv[0], "stop")  == 0) { telemetry_stop();  return 0; }
    if (strcmp(argv[0], "dump")  == 0) { telemetry_dump();  return 0; }
    fprintf(stderr, "Unknown telemetry subcommand: %s\n", argv[0]);
    return 1;
}

/* ------------------------------------------------------------------ */
/* AXB35 DAEMON                                                        */
/* ------------------------------------------------------------------ */
#define DAEMON_PID_FILE "/tmp/axb35-daemon.pid"

static void axb35_daemonize(void)
{
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid > 0) {
        FILE *fp = fopen(DAEMON_PID_FILE, "w");
        if (fp) { fprintf(fp, "%d\n", pid); fclose(fp); }
        printf("Daemon: started (PID %d)\n", pid);
        exit(0);
    }
    setsid();
    freopen("/dev/null", "r", stdin);
    freopen("/dev/null", "w", stdout);
    freopen("/dev/null", "w", stderr);
    while (1) {
        TelemetrySample s;
        axb35_collect_sample(&s);
        FILE *fp = fopen(TELEMETRY_FILE, "w");
        if (fp) {
            long ts = s.ts_ms / 1000;
            fprintf(fp, "# HELP axb35_cpu_temp_c CPU temperature from EC sensor\n");
            fprintf(fp, "# TYPE axb35_cpu_temp_c gauge\n");
            fprintf(fp, "axb35_cpu_temp_c %ld %ld\n", s.cpu_ec, ts);
            fprintf(fp, "# HELP axb35_cpu_k10_temp_c CPU temperature from k10temp\n");
            fprintf(fp, "# TYPE axb35_cpu_k10_temp_c gauge\n");
            fprintf(fp, "axb35_cpu_k10_temp_c %ld %ld\n", s.cpu_raw / 1000, ts);
            fprintf(fp, "# HELP axb35_gpu_temp_c GPU temperature\n");
            fprintf(fp, "# TYPE axb35_gpu_temp_c gauge\n");
            fprintf(fp, "axb35_gpu_temp_c %ld %ld\n", s.gpu_temp / 1000, ts);
            fprintf(fp, "# HELP axb35_gpu_power_watts GPU power average\n");
            fprintf(fp, "# TYPE axb35_gpu_power_watts gauge\n");
            fprintf(fp, "axb35_gpu_power_watts %.3f %ld\n", s.gpu_power / 1000000.0, ts);
            fprintf(fp, "# HELP axb35_gpu_freq_hz GPU frequency\n");
            fprintf(fp, "# TYPE axb35_gpu_freq_hz gauge\n");
            fprintf(fp, "axb35_gpu_freq_hz %ld %ld\n", s.gpu_freq, ts);
            for (int fi = 1; fi <= 3; fi++) {
                fprintf(fp, "# HELP axb35_fan_rpm Fan RPM\n");
                fprintf(fp, "# TYPE axb35_fan_rpm gauge\n");
                fprintf(fp, "axb35_fan_rpm{fan=\"%d\"} %ld %ld\n", fi, s.rpm[fi], ts);
            }
            fprintf(fp, "# HELP axb35_vram_used_bytes VRAM used bytes\n");
            fprintf(fp, "# TYPE axb35_vram_used_bytes gauge\n");
            fprintf(fp, "axb35_vram_used_bytes %ld %ld\n", s.vram_used, ts);
            fprintf(fp, "# HELP axb35_gtt_used_bytes GTT used bytes\n");
            fprintf(fp, "# TYPE axb35_gtt_used_bytes gauge\n");
            fprintf(fp, "axb35_gtt_used_bytes %ld %ld\n", s.gtt_used, ts);
            fprintf(fp, "# HELP axb35_mem_available_bytes Available memory\n");
            fprintf(fp, "# TYPE axb35_mem_available_bytes gauge\n");
            fprintf(fp, "axb35_mem_available_bytes %ld %ld\n", s.mem_avail * 1024, ts);
            fprintf(fp, "# HELP axb35_apu_mode APU power mode\n");
            fprintf(fp, "# TYPE axb35_apu_mode gauge\n");
            fprintf(fp, "axb35_apu_mode{profile=\"%s\"} 1 %ld\n", s.apu_mode, ts);
            fclose(fp);
        }
        struct timespec ts;
        ts.tv_sec = TELEMETRY_POLL_MS / 1000;
        ts.tv_nsec = (long)(TELEMETRY_POLL_MS % 1000) * 1000000L;
        nanosleep(&ts, NULL);
    }
}

static int axb35_cmd_daemon(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: daemon start|stop|status\n"); return 1; }
    if (strcmp(argv[0], "status") == 0) {
        FILE *fp = fopen(DAEMON_PID_FILE, "r");
        if (!fp) { printf("Daemon: not running\n"); return 0; }
        char buf[32]; buf[0] = 0;
        fgets(buf, sizeof(buf), fp); fclose(fp);
        long pid = atol(buf);
        char path[64];
        snprintf(path, sizeof(path), "/proc/%ld", pid);
        if (access(path, F_OK) == 0) printf("Daemon: running (PID %ld)\n", pid);
        else { printf("Daemon: PID file stale, not running\n"); unlink(DAEMON_PID_FILE); }
        return 0;
    }
    if (strcmp(argv[0], "start") == 0) { axb35_daemonize(); return 0; }
    if (strcmp(argv[0], "stop") == 0) {
        FILE *fp = fopen(DAEMON_PID_FILE, "r");
        if (!fp) { printf("Daemon: not running\n"); return 0; }
        char buf[32]; buf[0] = 0;
        fgets(buf, sizeof(buf), fp); fclose(fp);
        long pid = atol(buf);
        char cmd[64]; snprintf(cmd, sizeof(cmd), "kill %ld", pid);
        if (system(cmd) == 0) { unlink(DAEMON_PID_FILE); printf("Daemon: stopped\n"); }
        else { printf("Daemon: failed to stop (PID %ld)\n", pid); }
        return 0;
    }
    fprintf(stderr, "Unknown daemon subcommand: %s\n", argv[0]);
    return 1;
}

/* ================================================================== */
/*                        Z13 HANDLERS                                 */
/* ================================================================== */

#define ASUS_WMI       "/sys/devices/platform/asus-nb-wmi"
#define CURVE_POINTS 8
#define Z13_FAN_COUNT 2

/* ------------------------------------------------------------------ */
/* Z13 GET                                                             */
/* ------------------------------------------------------------------ */

static int z13_show_fan(int idx)
{
    char path[256];
    snprintf(path, sizeof(path), "%s/fan%d_input", get_hwmon_path("asus"), idx);
    long rpm = sysfs_read_long(path);
    printf("fan%d_rpm: %ld\n", idx, rpm);
    snprintf(path, sizeof(path), "%s/pwm%d_enable", get_hwmon_path("asus"), idx);
    long mode = sysfs_read_long(path);
    printf("fan%d_mode: %ld (0=auto, 1=manual, 2=custom)\n", idx, mode);
    if (mode == 2) {
        long temp = idx == 1 ?
            sysfs_read_hwmon_long("k10temp", "/temp1_input") / 1000 :
            sysfs_read_hwmon_long("amdgpu", "/temp1_input") / 1000;
        int pwm_percent = z13_estimate_fan_pwm_percent(idx, temp);
        int level = z13_normalized_fan_level(pwm_percent);
        printf("fan%d_level: %d (~%d%% PWM, normalized 0-5)\n",
               idx, level, pwm_percent);
        printf("fan%d_curve:\n", idx);
        for (int p = 1; p <= CURVE_POINTS; p++) {
            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp", get_hwmon_path("asus_custom_fan_curve"), idx, p);
            long t = sysfs_read_long(path);
            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm", get_hwmon_path("asus_custom_fan_curve"), idx, p);
            long pwm = sysfs_read_long(path);
            printf("  point %d: %ld°C -> %ld%% PWM (raw %ld)\n", p, t, pwm * 100 / 255, pwm);
        }
    }
    return 0;
}

static int z13_cmd_get(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: get [all|temp|fan1|fan2|gpu|battery|tdp|profile|charge_mode]\n"); return 1; }
    const char *sub = argv[0];

    if (strcmp(sub, "all") == 0) {
        long cpu = sysfs_read_hwmon_long("k10temp", "/temp1_input");
        long gpu_t = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
        printf("cpu_temp: %ld °C\n", cpu / 1000);
        printf("gpu_temp: %ld °C\n", gpu_t / 1000);
        for (int fi = 1; fi <= Z13_FAN_COUNT; fi++) { z13_show_fan(fi); }
        long gp = sysfs_read_hwmon_long("amdgpu", "/power1_average");
        long gf = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
        printf("gpu_power: %.2f W\n", gp / 1000000.0);
        printf("gpu_freq: %ld Hz\n", gf);
        char buf[64];
        if (sysfs_read("/sys/class/power_supply/BAT0/capacity", buf, sizeof(buf)) == 0)
            printf("battery_capacity: %s%%\n", buf);
        if (sysfs_read("/sys/class/power_supply/BAT0/status", buf, sizeof(buf)) == 0)
            printf("battery_status: %s\n", buf);
        if (sysfs_read(ASUS_WMI "/ppt_fppt", buf, sizeof(buf)) == 0)
            printf("ppt_fppt: %s\n", buf);
        FILE *f = fopen("/sys/firmware/acpi/platform_profile", "r");
        if (f) { char pb[64]; pb[0]=0; fgets(pb, sizeof(pb), f); fclose(f);
            char *nl = strchr(pb, '\n'); if (nl) *nl = 0;
            printf("platform_profile: %s\n", pb); }
        if (sysfs_read(ASUS_WMI "/charge_mode", buf, sizeof(buf)) == 0)
            printf("charge_mode: %s\n", buf);
        return 0;
    }

    if (strcmp(sub, "temp") == 0) {
        long cpu = sysfs_read_hwmon_long("k10temp", "/temp1_input");
        long gpu = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
        printf("cpu_temp: %ld °C\n", cpu / 1000);
        printf("gpu_temp: %ld °C\n", gpu / 1000);
        return 0;
    }

    if (strcmp(sub, "fan1") == 0) return z13_show_fan(1);
    if (strcmp(sub, "fan2") == 0) return z13_show_fan(2);

    if (strcmp(sub, "gpu") == 0) {
        long p = sysfs_read_hwmon_long("amdgpu", "/power1_average");
        long f = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
        long t = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
        printf("gpu_power: %.2f W\n", p / 1000000.0);
        printf("gpu_freq: %ld Hz\n", f);
        printf("gpu_temp: %ld °C\n", t / 1000);
        long vram = sysfs_read_long("/sys/class/drm/card1/device/mem_info_vram_used");
        long gtt  = sysfs_read_long("/sys/class/drm/card1/device/mem_info_gtt_used");
        if (vram >= 0) printf("vram_used: %ld\n", vram);
        if (gtt >= 0)  printf("gtt_used: %ld\n", gtt);
        return 0;
    }

    if (strcmp(sub, "battery") == 0) {
        char buf[64];
        if (sysfs_read("/sys/class/power_supply/BAT0/capacity", buf, sizeof(buf)) == 0)
            printf("battery_capacity: %s%%\n", buf);
        else printf("battery: N/A\n");
        if (sysfs_read("/sys/class/power_supply/BAT0/status", buf, sizeof(buf)) == 0)
            printf("battery_status: %s\n", buf);
        if (sysfs_read("/sys/class/power_supply/BAT0/power_now", buf, sizeof(buf)) == 0) {
            char pbuf[64]; fmt_power(pbuf, sizeof(pbuf), atol(buf));
            printf("battery_power: %s\n", pbuf);
        }
        return 0;
    }

    if (strcmp(sub, "tdp") == 0) {
        char val[64];
        if (sysfs_read(ASUS_WMI "/ppt_fppt", val, sizeof(val)) == 0) printf("ppt_fppt: %s\n", val);
        if (sysfs_read(ASUS_WMI "/ppt_pl1_spl", val, sizeof(val)) == 0) printf("ppt_pl1_spl: %s\n", val);
        if (sysfs_read(ASUS_WMI "/ppt_pl2_sppt", val, sizeof(val)) == 0) printf("ppt_pl2_sppt: %s\n", val);
        if (sysfs_read(ASUS_WMI "/ppt_apu_sppt", val, sizeof(val)) == 0) printf("ppt_apu_sppt: %s\n", val);
        if (sysfs_read(ASUS_WMI "/ppt_platform_sppt", val, sizeof(val)) == 0) printf("ppt_platform_sppt: %s\n", val);
        return 0;
    }

    if (strcmp(sub, "profile") == 0) {
        FILE *f = fopen("/sys/firmware/acpi/platform_profile", "r");
        if (f) {
            char buf[64]; buf[0]=0; fgets(buf, sizeof(buf), f); fclose(f);
            char *nl = strchr(buf, '\n'); if (nl) *nl = 0;
            printf("platform_profile: %s\n", buf);
        } else { printf("platform_profile: N/A\n"); }
        f = fopen("/sys/firmware/acpi/platform_profile_choices", "r");
        if (f) {
            char buf[128]; buf[0]=0; fgets(buf, sizeof(buf), f); fclose(f);
            char *nl = strchr(buf, '\n'); if (nl) *nl = 0;
            printf("available_profiles: %s\n", buf);
        }
        return 0;
    }

    if (strcmp(sub, "charge_mode") == 0) {
        char val[64];
        if (sysfs_read(ASUS_WMI "/charge_mode", val, sizeof(val)) == 0)
            printf("charge_mode: %s (0=full charge, 1=limit charge)\n", val);
        else printf("charge_mode: N/A\n");
        return 0;
    }

    if (strcmp(sub, "boot_sound") == 0) {
        char val[64];
        if (sysfs_read(ASUS_WMI "/boot_sound", val, sizeof(val)) == 0) printf("boot_sound: %s\n", val);
        else printf("boot_sound: N/A\n");
        return 0;
    }

    if (strcmp(sub, "panel_od") == 0) {
        char val[64];
        if (sysfs_read(ASUS_WMI "/panel_od", val, sizeof(val)) == 0) printf("panel_od: %s\n", val);
        else printf("panel_od: N/A\n");
        return 0;
    }

    fprintf(stderr, "Unknown get target: %s (use all, temp, fan<N>, gpu, battery, tdp, profile, charge_mode)\n", sub);
    return 1;
}

/* ------------------------------------------------------------------ */
/* Z13 SET                                                             */
/* ------------------------------------------------------------------ */

static int parse_ints(const char *str, int *vals, int max)
{
    int n = 0;
    const char *p = str;
    while (*p && n < max) { vals[n++] = atoi(p); p = strchr(p, ','); if (!p) break; p++; }
    return n;
}

static int z13_cmd_set(int argc, char **argv)
{
    if (argc < 2) { fprintf(stderr, "Usage: set [fan|profile|charge_mode|ppt_fppt|...]\n"); return 1; }

    if (strcmp(argv[0], "profile") == 0 && argc >= 2) {
        const char *mode = argv[1];
        if (strcmp(mode, "quiet") != 0 && strcmp(mode, "balanced") != 0 && strcmp(mode, "performance") != 0) {
            fprintf(stderr, "Invalid profile: %s (use quiet, balanced, performance)\n", mode); return 1;
        }
        /* Set platform_profile */
        if (sysfs_write("/sys/firmware/acpi/platform_profile", mode) == 0)
            printf("platform_profile set to %s\n", mode);
        else { fprintf(stderr, "Failed to set platform_profile\n"); return 1; }
        if (z13_sync_profile_power_limits() != 0) {
            fprintf(stderr, "Failed to synchronize PPT limits\n");
            return 1;
        }
        printf("PPT limits set to %ld W\n",
               z13_profile_power_limit(mode));
        return 0;
    }

    if (strcmp(argv[0], "charge_mode") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/charge_mode", argv[1]) == 0) printf("charge_mode set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set charge_mode\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "ppt_fppt") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/ppt_fppt", argv[1]) == 0) printf("ppt_fppt set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set ppt_fppt\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "ppt_pl1_spl") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/ppt_pl1_spl", argv[1]) == 0) printf("ppt_pl1_spl set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set ppt_pl1_spl\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "ppt_pl2_sppt") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/ppt_pl2_sppt", argv[1]) == 0) printf("ppt_pl2_sppt set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set ppt_pl2_sppt\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "boot_sound") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/boot_sound", argv[1]) == 0) printf("boot_sound set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set boot_sound\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "panel_od") == 0 && argc >= 2) {
        if (sysfs_write(ASUS_WMI "/panel_od", argv[1]) == 0) printf("panel_od set to %s\n", argv[1]);
        else { fprintf(stderr, "Failed to set panel_od\n"); return 1; }
        return 0;
    }

    if (strcmp(argv[0], "fan") == 0 && argc >= 4) {
        int fan = atoi(argv[1]);
        if (fan < 1 || fan > Z13_FAN_COUNT) { fprintf(stderr, "Invalid fan number: %d (use 1 or 2)\n", fan); return 1; }
        if (strcmp(argv[2], "curve") == 0 && argc >= 4) {
            int vals[16];
            int n = parse_ints(argv[3], vals, 16);
            if (n != CURVE_POINTS * 2) {
                fprintf(stderr, "Expected %d values (temp,pwm pairs), got %d\n", CURVE_POINTS * 2, n);
                return 1;
            }
            for (int p = 0; p < CURVE_POINTS; p++) {
                int temp = vals[p * 2], pct = vals[p * 2 + 1], pwm = (pct * 255 + 50) / 100;
                if (pwm < 0) pwm = 0;
                if (pwm > 255) pwm = 255;
                char path[256], buf[32];
                snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp", get_hwmon_path("asus_custom_fan_curve"), fan, p + 1);
                snprintf(buf, sizeof(buf), "%d", temp);
                if (sysfs_write(path, buf) != 0) { fprintf(stderr, "Failed to set point %d temp\n", p + 1); return 1; }
                snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm", get_hwmon_path("asus_custom_fan_curve"), fan, p + 1);
                snprintf(buf, sizeof(buf), "%d", pwm);
                if (sysfs_write(path, buf) != 0) { fprintf(stderr, "Failed to set point %d pwm\n", p + 1); return 1; }
                printf("fan%d point %d: %d°C -> %d%% PWM (raw %d)\n", fan, p + 1, temp, pct, pwm);
            }
            return 0;
        }
        if (strcmp(argv[2], "enable") == 0 && argc >= 4) {
            char path[256];
            snprintf(path, sizeof(path), "%s/pwm%d_enable", get_hwmon_path("asus_custom_fan_curve"), fan);
            if (sysfs_write(path, argv[3]) == 0) printf("fan%d enable set to %s\n", fan, argv[3]);
            else { fprintf(stderr, "Failed to set fan%d enable\n", fan); return 1; }
            return 0;
        }
        fprintf(stderr, "Unknown fan subcommand: %s\n", argv[2]); return 1;
    }

    fprintf(stderr, "Unknown set target: %s\n", argv[0]); return 1;
}

/* ------------------------------------------------------------------ */
/* Z13 LOAD                                                            */
/* ------------------------------------------------------------------ */

static int z13_cmd_load(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: load <json-file>\n"); return 1; }
    FILE *fp = fopen(argv[0], "r");
    if (!fp) { fprintf(stderr, "Cannot open %s: %s\n", argv[0], strerror(errno)); return 1; }
    fseek(fp, 0, SEEK_END);
    long fsz = ftell(fp);
    rewind(fp);
    char *data = malloc(fsz + 1);
    if (!data) { fclose(fp); return 1; }
    fread(data, 1, fsz, fp);
    data[fsz] = 0;
    fclose(fp);

    char *ptr = data;
    while (ptr && *ptr) {
        char *key_start = strchr(ptr, '\"');
        if (!key_start) break;
        key_start++;
        char *key_end = strchr(key_start, '\"');
        if (!key_end) break;
        *key_end = 0;
        char *key = key_start;
        char *val_start = strchr(key_end + 1, ':');
        if (!val_start) { ptr = key_end + 1; continue; }
        val_start++;
        while (*val_start == ' ' || *val_start == '\"') val_start++;
        char *val_end = strchr(val_start, '\"');
        if (!val_end) val_end = strchr(val_start, ',');
        if (!val_end) val_end = strchr(val_start, '}');
        if (!val_end) { ptr = key_end + 1; continue; }
        int val_len = val_end - val_start;
        char val[256];
        strncpy(val, val_start, val_len);
        val[val_len] = 0;
        for (char *c = val + val_len - 1; c >= val; c--)
            if (*c == ' ' || *c == ',' || *c == '}' || *c == '\"') *c = 0;
            else break;

        if (strncmp(key, "platform_profile", 16) == 0) {
            sysfs_write("/sys/firmware/acpi/platform_profile", val);
            printf("platform_profile: %s\n", val);
        } else if (strncmp(key, "charge_mode", 11) == 0) {
            sysfs_write(ASUS_WMI "/charge_mode", val);
            printf("charge_mode: %s\n", val);
        } else if (strncmp(key, "ppt_fppt", 8) == 0) {
            sysfs_write(ASUS_WMI "/ppt_fppt", val);
            printf("ppt_fppt: %s\n", val);
        } else if (strncmp(key, "ppt_pl1_spl", 11) == 0) {
            sysfs_write(ASUS_WMI "/ppt_pl1_spl", val);
            printf("ppt_pl1_spl: %s\n", val);
        } else if (strncmp(key, "ppt_pl2_sppt", 12) == 0) {
            sysfs_write(ASUS_WMI "/ppt_pl2_sppt", val);
            printf("ppt_pl2_sppt: %s\n", val);
        } else if (strncmp(key, "boot_sound", 10) == 0) {
            sysfs_write(ASUS_WMI "/boot_sound", val);
            printf("boot_sound: %s\n", val);
        } else if (strncmp(key, "panel_od", 8) == 0) {
            sysfs_write(ASUS_WMI "/panel_od", val);
            printf("panel_od: %s\n", val);
        } else if (strstr(key, "fan") && strstr(key, "_curve")) {
            int fan = (key[3] == '1') ? 1 : 2;
            int vals[16];
            int n = parse_ints(val, vals, 16);
            if (n == CURVE_POINTS * 2) {
                for (int p = 0; p < CURVE_POINTS; p++) {
                    char path[256], buf[32];
                    snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp", get_hwmon_path("asus_custom_fan_curve"), fan, p + 1);
                    snprintf(buf, sizeof(buf), "%d", vals[p * 2]);
                    sysfs_write(path, buf);
                    snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm", get_hwmon_path("asus_custom_fan_curve"), fan, p + 1);
                    snprintf(buf, sizeof(buf), "%d", vals[p * 2 + 1]);
                    sysfs_write(path, buf);
                }
                printf("fan%d_curve loaded: %s\n", fan, val);
            } else {
                fprintf(stderr, "fan%d_curve: expected %d values, got %d\n", fan, CURVE_POINTS * 2, n);
            }
        } else if (strstr(key, "fan") && strstr(key, "_enable")) {
            int fan = (key[3] == '1') ? 1 : 2;
            char path[256];
            snprintf(path, sizeof(path), "%s/pwm%d_enable", get_hwmon_path("asus_custom_fan_curve"), fan);
            sysfs_write(path, val);
            printf("fan%d_enable: %s\n", fan, val);
        }
        ptr = val_end + 1;
    }
    free(data);
    printf("Loaded config from %s\n", argv[0]);
    return 0;
}

/* ------------------------------------------------------------------ */
/* Z13 TELEMETRY & DAEMON                                              */
/* ------------------------------------------------------------------ */

#define Z13_TELEMETRY_FILE "/tmp/z13-telemetry.prom"
#define Z13_DAEMON_PID_FILE "/tmp/z13-daemon.pid"

static void z13_collect_sample(TelemetrySample *s)
{
    s->ts_ms = now_ms();
    s->cpu_ec   = sysfs_read_hwmon_long("k10temp", "/temp1_input") / 1000;
    s->cpu_raw  = sysfs_read_hwmon_long("k10temp", "/temp1_input");
    s->gpu_temp = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
    s->gpu_power = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    s->gpu_freq  = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    s->rpm[1] = sysfs_read_hwmon_long("asus", "/fan1_input");
    s->rpm[2] = sysfs_read_hwmon_long("asus", "/fan2_input");
    s->rpm[3] = -1;
    s->vram_used = sysfs_read_long("/sys/class/drm/card1/device/mem_info_vram_used");
    s->gtt_used  = sysfs_read_long("/sys/class/drm/card1/device/mem_info_gtt_used");
    FILE *fp = fopen("/proc/meminfo", "r");
    if (fp) {
        char buf[128]; long avail = -1;
        while (fgets(buf, sizeof(buf), fp))
            if (sscanf(buf, "MemAvailable: %ld", &avail) == 1) break;
        s->mem_avail = avail;
        fclose(fp);
    } else { s->mem_avail = -1; }
    char val[64];
    sysfs_read("/sys/firmware/acpi/platform_profile", val, sizeof(val));
    snprintf(s->apu_mode, sizeof(s->apu_mode), "%s", val[0] ? val : "unknown");
}

static void z13_write_prometheus(TelemetrySample *s)
{
    FILE *fp = fopen(Z13_TELEMETRY_FILE, "w");
    if (!fp) return;
    long ts = s->ts_ms / 1000;
    fprintf(fp, "# HELP z13_cpu_temp_c CPU temperature\n");
    fprintf(fp, "# TYPE z13_cpu_temp_c gauge\n");
    fprintf(fp, "z13_cpu_temp_c %ld %ld\n", s->cpu_ec, ts);
    fprintf(fp, "# HELP z13_gpu_temp_c GPU temperature\n");
    fprintf(fp, "# TYPE z13_gpu_temp_c gauge\n");
    fprintf(fp, "z13_gpu_temp_c %ld %ld\n", s->gpu_temp / 1000, ts);
    fprintf(fp, "# HELP z13_gpu_power_watts GPU power average\n");
    fprintf(fp, "# TYPE z13_gpu_power_watts gauge\n");
    fprintf(fp, "z13_gpu_power_watts %.3f %ld\n", s->gpu_power / 1000000.0, ts);
    fprintf(fp, "# HELP z13_gpu_freq_hz GPU frequency\n");
    fprintf(fp, "# TYPE z13_gpu_freq_hz gauge\n");
    fprintf(fp, "z13_gpu_freq_hz %ld %ld\n", s->gpu_freq, ts);
    for (int fi = 1; fi <= 2; fi++) {
        fprintf(fp, "# HELP z13_fan_rpm Fan RPM\n");
        fprintf(fp, "# TYPE z13_fan_rpm gauge\n");
        fprintf(fp, "z13_fan_rpm{fan=\"%d\"} %ld %ld\n", fi, s->rpm[fi], ts);
    }
    fprintf(fp, "# HELP z13_vram_used_bytes VRAM used bytes\n");
    fprintf(fp, "# TYPE z13_vram_used_bytes gauge\n");
    fprintf(fp, "z13_vram_used_bytes %ld %ld\n", s->vram_used, ts);
    fprintf(fp, "# HELP z13_gtt_used_bytes GTT used bytes\n");
    fprintf(fp, "# TYPE z13_gtt_used_bytes gauge\n");
    fprintf(fp, "z13_gtt_used_bytes %ld %ld\n", s->gtt_used, ts);
    fprintf(fp, "# HELP z13_mem_available_bytes Available memory\n");
    fprintf(fp, "# TYPE z13_mem_available_bytes gauge\n");
    fprintf(fp, "z13_mem_available_bytes %ld %ld\n", s->mem_avail * 1024, ts);
    fprintf(fp, "# HELP z13_profile Platform profile\n");
    fprintf(fp, "# TYPE z13_profile gauge\n");
    fprintf(fp, "z13_profile{profile=\"%s\"} 1 %ld\n", s->apu_mode, ts);
    fclose(fp);
}

static void *z13_telemetry_loop(void *arg)
{
    (void)arg;
    while (telemetry_running) {
        TelemetrySample s;
        z13_collect_sample(&s);
        z13_write_prometheus(&s);
        struct timespec ts;
        ts.tv_sec = TELEMETRY_POLL_MS / 1000;
        ts.tv_nsec = (long)(TELEMETRY_POLL_MS % 1000) * 1000000L;
        nanosleep(&ts, NULL);
    }
    return NULL;
}

static void z13_telemetry_start(void)
{
    if (telemetry_running) { printf("Telemetry: already running\n"); return; }
    telemetry_running = 1;
    pthread_t t;
    pthread_create(&t, NULL, z13_telemetry_loop, NULL);
    pthread_detach(t);
    printf("Telemetry: started\n");
}

static void z13_telemetry_stop(void)
{
    if (!telemetry_running) { printf("Telemetry: not running\n"); return; }
    telemetry_running = 0;
    printf("Telemetry: stopped\n");
}

static void z13_telemetry_dump(void)
{
    FILE *fp = fopen(Z13_TELEMETRY_FILE, "r");
    if (!fp) { printf("No telemetry data found (%s)\n", Z13_TELEMETRY_FILE); return; }
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), fp)) > 0) fwrite(buf, 1, n, stdout);
    fclose(fp);
}

static int z13_cmd_telemetry(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: telemetry start|stop|dump\n"); return 1; }
    if (strcmp(argv[0], "start") == 0) { z13_telemetry_start(); return 0; }
    if (strcmp(argv[0], "stop")  == 0) { z13_telemetry_stop();  return 0; }
    if (strcmp(argv[0], "dump")  == 0) { z13_telemetry_dump();  return 0; }
    fprintf(stderr, "Unknown telemetry subcommand: %s\n", argv[0]);
    return 1;
}

static void z13_daemonize(void)
{
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); exit(1); }
    if (pid > 0) {
        FILE *fp = fopen(Z13_DAEMON_PID_FILE, "w");
        if (fp) { fprintf(fp, "%d\n", pid); fclose(fp); }
        printf("Daemon: started (PID %d)\n", pid);
        exit(0);
    }
    setsid();
    freopen("/dev/null", "r", stdin);
    freopen("/dev/null", "w", stdout);
    freopen("/dev/null", "w", stderr);
    while (1) {
        TelemetrySample s;
        z13_collect_sample(&s);
        z13_write_prometheus(&s);
        struct timespec ts;
        ts.tv_sec = TELEMETRY_POLL_MS / 1000;
        ts.tv_nsec = (long)(TELEMETRY_POLL_MS % 1000) * 1000000L;
        nanosleep(&ts, NULL);
    }
}

static int z13_cmd_daemon(int argc, char **argv)
{
    if (argc < 1) { fprintf(stderr, "Usage: daemon start|stop|status\n"); return 1; }
    if (strcmp(argv[0], "status") == 0) {
        FILE *fp = fopen(Z13_DAEMON_PID_FILE, "r");
        if (!fp) { printf("Daemon: not running\n"); return 0; }
        char buf[32]; buf[0] = 0;
        fgets(buf, sizeof(buf), fp); fclose(fp);
        long pid = atol(buf);
        char path[64]; snprintf(path, sizeof(path), "/proc/%ld", pid);
        if (access(path, F_OK) == 0) printf("Daemon: running (PID %ld)\n", pid);
        else { printf("Daemon: PID file stale, not running\n"); unlink(Z13_DAEMON_PID_FILE); }
        return 0;
    }
    if (strcmp(argv[0], "start") == 0) { z13_daemonize(); return 0; }
    if (strcmp(argv[0], "stop") == 0) {
        FILE *fp = fopen(Z13_DAEMON_PID_FILE, "r");
        if (!fp) { printf("Daemon: not running\n"); return 0; }
        char buf[32]; buf[0] = 0;
        fgets(buf, sizeof(buf), fp); fclose(fp);
        long pid = atol(buf);
        char cmd[64]; snprintf(cmd, sizeof(cmd), "kill %ld", pid);
        if (system(cmd) == 0) { unlink(Z13_DAEMON_PID_FILE); printf("Daemon: stopped\n"); }
        else { printf("Daemon: failed to stop (PID %ld)\n", pid); }
        return 0;
    }
    fprintf(stderr, "Unknown daemon subcommand: %s\n", argv[0]);
    return 1;
}
