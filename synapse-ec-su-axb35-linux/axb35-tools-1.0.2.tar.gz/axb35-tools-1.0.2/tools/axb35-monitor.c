/* axb35-monitor.c — Multi-platform system monitor (AXB35 / Z13 ROG Flow)
 * Copyright (C) 2025  Andrea "KJ" Perrucci
 * License: GPL-2.0-only
 */

#define _POSIX_C_SOURCE 200809L
#include "sysfs-helpers.h"
#include "platform-policy.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/ioctl.h>
#include <dirent.h>

#define CSI_RESET   "\033[0m"
#define CSI_BOLD    "\033[1m"
#define CSI_GREEN   "\033[32m"
#define CSI_YELLOW  "\033[33m"
#define CSI_BLUE    "\033[34m"
#define CSI_MAGENTA "\033[35m"
#define CSI_CYAN    "\033[36m"
#define CSI_RED     "\033[31m"

static volatile int running = 1;
static int term_rows = 24, term_cols = 80;
static double interval = 1.0;
static int platform_fan_count = 3;
static const char *platform_name = "unknown";
static int control_mode = 0;

static void handle_sigint(int sig) { (void)sig; running = 0; }

/* ---------- Data ---------- */

/* ANSI CUP è 1-indexed; questa macro garantisce colonna >= 1 */
#define CUP1(row, col) printf("\033[%d;%dH", (int)(row), (int)(col > 0 ? col : 1))
#define CUP CUP1
#define MAX_FANS 4
typedef struct {
    long rpm[MAX_FANS]; char mode[MAX_FANS][64]; long level[MAX_FANS];
    long pwm_percent[MAX_FANS];
    char ru[MAX_FANS][64], rd[MAX_FANS][64];
    char apu_mode[64];          /* AXB35: power_mode; Z13: platform_profile */
    long cpu_ec, tmin, tmax;    /* AXB35 EC temp; Z13: k10temp */
    long battery_capacity;      /* Z13 only */
    char battery_status[16];    /* Z13 only */
    long ppt_fppt;              /* Z13 only */
    long tdp_watts;             /* Active TDP/PPT limit in watts */
    long expected_tdp_watts;    /* Profile-matched TDP/PPT limit */
    long gpu_power_uw;          /* GPU power in microwatts */
    long gpu_freq_hz;           /* GPU frequency in Hz */
    long gpu_temp_c;            /* GPU temperature in degrees Celsius */
} D;

/* ---------- Platform ops (function pointers) ---------- */
typedef struct {
    const char *name;
    int  fan_count;
    void (*fetch)(D *d);
    void (*print_json)(void);
} Platform;

/* ---------- AXB35 platform ---------- */
static void axb35_fetch(D *d)
{
    char p[256];
    for (int i = 1; i <= 3; i++) {
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/rpm", i); d->rpm[i] = sysfs_read_long(p);
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/mode", i); sysfs_read(p, d->mode[i], sizeof(d->mode[i]));
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/level", i); d->level[i] = sysfs_read_long(p);
        d->pwm_percent[i] = d->level[i] >= 0 ? d->level[i] * 20 : -1;
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/rampup_curve", i); sysfs_read(p, d->ru[i], sizeof(d->ru[i]));
        snprintf(p, sizeof(p), AXB35_PATH "/fan%d/rampdown_curve", i); sysfs_read(p, d->rd[i], sizeof(d->rd[i]));
    }
    sysfs_read(AXB35_PATH "/apu/power_mode", d->apu_mode, sizeof(d->apu_mode));
    d->cpu_ec = sysfs_read_long(AXB35_PATH "/temp1/temp");
    d->tmin   = sysfs_read_long(AXB35_PATH "/temp1/min");
    d->tmax   = sysfs_read_long(AXB35_PATH "/temp1/max");
    d->battery_capacity = -1;  /* AXB35 has no battery */
    d->ppt_fppt = -1;
    d->battery_status[0] = 0;
    /* Derive TDP from APU power mode */
    if (strcmp(d->apu_mode, "quiet") == 0)
        d->tdp_watts = 65;
    else if (strcmp(d->apu_mode, "balanced") == 0)
        d->tdp_watts = 85;
    else if (strcmp(d->apu_mode, "performance") == 0)
        d->tdp_watts = 120;
    else
        d->tdp_watts = -1;
    d->expected_tdp_watts = d->tdp_watts;
    /* GPU readings */
    d->gpu_power_uw = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    d->gpu_freq_hz  = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    d->gpu_temp_c   = sysfs_read_hwmon_long("amdgpu", "/temp1_input") / 1000;
}

static void axb35_print_json(void)
{
    char val[64], ru[256], rd[256], path[256];
    printf("{\n");
    for (int i = 1; i <= 3; i++) {
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rpm", i); long rpm = sysfs_read_long(path);
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", i); sysfs_read(path, val, sizeof(val));
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/level", i); long level = sysfs_read_long(path);
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampup_curve", i); sysfs_read(path, ru, sizeof(ru));
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampdown_curve", i); sysfs_read(path, rd, sizeof(rd));
        printf("  \"fan%d\": {\n", i);
        printf("    \"rpm\": %ld,\n", rpm);
        printf("    \"mode\": \"%s\",\n", val);
        if (level >= 0) printf("    \"level\": %ld,\n", level);
        if (ru[0])      printf("    \"rampup_curve\": \"%s\",\n", ru);
        if (rd[0])      printf("    \"rampdown_curve\": \"%s\"\n", rd);
        else            printf("    \"rampdown_curve\": \"\"\n");
        printf("  },\n");
    }
    sysfs_read(AXB35_PATH "/apu/power_mode", val, sizeof(val));
    printf("  \"apu_power_mode\": \"%s\",\n", val[0] ? val : "unknown");
    printf("  \"cpu_temp\": %ld,\n", sysfs_read_long(AXB35_PATH "/temp1/temp"));
    printf("  \"cpu_temp_min\": %ld,\n", sysfs_read_long(AXB35_PATH "/temp1/min"));
    printf("  \"cpu_temp_max\": %ld,\n", sysfs_read_long(AXB35_PATH "/temp1/max"));
    /* TDP derived from APU mode */
    long tdp;
    if (strcmp(val, "quiet") == 0) tdp = 65;
    else if (strcmp(val, "balanced") == 0) tdp = 85;
    else if (strcmp(val, "performance") == 0) tdp = 120;
    else tdp = -1;
    printf("  \"tdp_watts\": %ld,\n", tdp);
    /* GPU readings formatted properly */
    long gp = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    long gf = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    long gt = sysfs_read_hwmon_long("amdgpu", "/temp1_input");
    printf("  \"gpu_power_watts\": %.2f,\n", gp / 1000000.0);
    printf("  \"gpu_freq_hz\": %ld,\n", gf);
    printf("  \"gpu_temp_c\": %ld,\n", gt / 1000);
    printf("  \"cpu_temp_raw\": %ld\n", sysfs_read_hwmon_long("k10temp", "/temp1_input"));
    printf("}\n");
}

/* ---------- Z13 platform ---------- */
static void z13_fetch(D *d)
{
    char buf[64];

    d->cpu_ec = sysfs_read_hwmon_long("k10temp", "/temp1_input") / 1000;
    d->gpu_temp_c = sysfs_read_hwmon_long("amdgpu", "/temp1_input") / 1000;

    /* Fans: 2 fans via hwmon */
    for (int i = 1; i <= 2; i++) {
        char path[256];
        snprintf(path, sizeof(path), "%s/fan%d_input", get_hwmon_path("asus"), i);
        d->rpm[i] = sysfs_read_long(path);
        /* Mode: read pwmX_enable from asus hwmon (stato reale HW) */
        snprintf(path, sizeof(path), "%s/pwm%d_enable", get_hwmon_path("asus"), i);
        long en = sysfs_read_long(path);
        if (en == 2) snprintf(d->mode[i], sizeof(d->mode[i]), "curve");
        else if (en == 1) snprintf(d->mode[i], sizeof(d->mode[i]), "fixed");
        else snprintf(d->mode[i], sizeof(d->mode[i]), "auto");

        /* Normalize the active curve PWM to the AXB35 0-5 level scale. */
        long fan_temp = i == 1 ? d->cpu_ec : d->gpu_temp_c;
        d->pwm_percent[i] = en == 2 ?
            z13_estimate_fan_pwm_percent(i, fan_temp) : -1;
        d->level[i] = z13_normalized_fan_level((int)d->pwm_percent[i]);
        d->ru[i][0] = 0;
        d->rd[i][0] = 0;

        const char *curve_base = get_hwmon_path("asus_custom_fan_curve");
        if (curve_base) {
            size_t used = 0;
            for (int point = 1; point <= 8 && used < sizeof(d->ru[i]); point++) {
                snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp",
                         curve_base, i, point);
                long temp = sysfs_read_long(path);
                snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm",
                         curve_base, i, point);
                long pwm = sysfs_read_long(path);
                int written = snprintf(d->ru[i] + used, sizeof(d->ru[i]) - used,
                                       "%s%ld:%ld", point == 1 ? "" : " ",
                                       temp, pwm * 100 / 255);
                if (written < 0 || (size_t)written >= sizeof(d->ru[i]) - used)
                    break;
                used += (size_t)written;
            }
        }
    }

    /* Platform profile */
    sysfs_read("/sys/firmware/acpi/platform_profile", d->apu_mode, sizeof(d->apu_mode));

    /* Z13 does not expose EC min/max tracking. */
    d->tmin   = -1;
    d->tmax   = -1;

    /* Battery */
    if (sysfs_read("/sys/class/power_supply/BAT0/capacity", buf, sizeof(buf)) == 0)
        d->battery_capacity = atol(buf);
    else
        d->battery_capacity = -1;
    if (sysfs_read("/sys/class/power_supply/BAT0/status", d->battery_status, sizeof(d->battery_status)) != 0)
        d->battery_status[0] = 0;

    /* PPT */
    d->ppt_fppt = sysfs_read_long("/sys/devices/platform/asus-nb-wmi/ppt_fppt");
    /* TDP from PPT FPPT and expected stock limit for the active profile */
    d->tdp_watts = d->ppt_fppt;
    d->expected_tdp_watts = z13_profile_power_limit(d->apu_mode);
    /* GPU readings */
    d->gpu_power_uw = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    d->gpu_freq_hz  = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
}

static void z13_print_json(void)
{
    char buf[64];
    long cpu_temp = sysfs_read_hwmon_long("k10temp", "/temp1_input") / 1000;
    long gpu_temp = sysfs_read_hwmon_long("amdgpu", "/temp1_input") / 1000;
    printf("{\n");
    for (int i = 1; i <= 2; i++) {
        char path[256];
        snprintf(path, sizeof(path), "%s/fan%d_input", get_hwmon_path("asus"), i);
        long rpm = sysfs_read_long(path);
        snprintf(path, sizeof(path), "%s/pwm%d_enable", get_hwmon_path("asus"), i);
        long en = sysfs_read_long(path);
        const char *mode = (en == 2) ? "curve" : (en == 1) ? "fixed" : "auto";
        printf("  \"fan%d\": {\n", i);
        printf("    \"rpm\": %ld,\n", rpm);
        printf("    \"mode\": \"%s\",\n", mode);
        long fan_temp = i == 1 ? cpu_temp : gpu_temp;
        int pwm_percent = en == 2 ?
            z13_estimate_fan_pwm_percent(i, fan_temp) : -1;
        int level = z13_normalized_fan_level(pwm_percent);
        if (level >= 0) {
            printf("    \"level\": %d,\n", level);
            printf("    \"estimated_pwm_percent\": %d,\n", pwm_percent);
        } else {
            printf("    \"level\": null,\n");
            printf("    \"estimated_pwm_percent\": null,\n");
        }
        printf("    \"curve\": [");
        const char *curve_base = get_hwmon_path("asus_custom_fan_curve");
        for (int point = 1; curve_base && point <= 8; point++) {
            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp",
                     curve_base, i, point);
            long temp = sysfs_read_long(path);
            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm",
                     curve_base, i, point);
            long pwm = sysfs_read_long(path);
            printf("%s{\"temp_c\":%ld,\"pwm_percent\":%ld}",
                   point == 1 ? "" : ",", temp, pwm * 100 / 255);
        }
        printf("]\n");
        printf("  },\n");
    }
    sysfs_read("/sys/firmware/acpi/platform_profile", buf, sizeof(buf));
    printf("  \"platform_profile\": \"%s\",\n", buf[0] ? buf : "unknown");
    printf("  \"cpu_temp\": %ld,\n", cpu_temp);
    printf("  \"gpu_temp\": %ld,\n", gpu_temp);
    /* GPU readings formatted properly */
    long gp = sysfs_read_hwmon_long("amdgpu", "/power1_average");
    long gf = sysfs_read_hwmon_long("amdgpu", "/freq1_input");
    printf("  \"gpu_power_watts\": %.2f,\n", gp / 1000000.0);
    printf("  \"gpu_freq_hz\": %ld,\n", gf);
    /* TDP from PPT */
    long ppt = sysfs_read_long("/sys/devices/platform/asus-nb-wmi/ppt_fppt");
    printf("  \"tdp_watts\": %ld,\n", ppt);
    printf("  \"expected_tdp_watts\": %ld,\n",
           z13_profile_power_limit(buf));
    sysfs_read("/sys/class/power_supply/BAT0/capacity", buf, sizeof(buf));
    printf("  \"battery_capacity\": %ld,\n", atol(buf));
    sysfs_read("/sys/class/power_supply/BAT0/status", buf, sizeof(buf));
    printf("  \"battery_status\": \"%s\",\n", buf);
    printf("  \"ppt_fppt\": %ld\n", ppt);
    printf("}\n");
}

/* ---------- Detect platform from DMI or compile-time override ---------- */
static int detect_platform(void)
{
#if defined(PLATFORM_AXB35)
    return 0;
#elif defined(PLATFORM_Z13)
    return 1;
#else
    /* Auto-detect via DMI */
    FILE *f = fopen("/sys/class/dmi/id/product_name", "r");
    if (!f) return -1;
    char buf[128]; buf[0] = 0;
    fgets(buf, sizeof(buf), f); fclose(f);
    char *nl = strchr(buf, '\n'); if (nl) *nl = 0;
    /* Z13 ROG Flow — match any ASUS ROG product */
    if (strstr(buf, "ROG") || strstr(buf, "GZ302") || strstr(buf, "GZ301")) return 1;
    /* AXB35 Bosgame / BeyondMax / MiniPC */
    if (strstr(buf, "BeyondMax") || strstr(buf, "Bosgame")) return 0;
    /* Fallback: check vendor */
    f = fopen("/sys/class/dmi/id/sys_vendor", "r");
    if (!f) return -1;
    buf[0] = 0;
    fgets(buf, sizeof(buf), f); fclose(f);
    nl = strchr(buf, '\n'); if (nl) *nl = 0;
    if (strstr(buf, "Bosgame")) return 0;
    if (strstr(buf, "ASUS")) return 1;
    return -1;
#endif
}

/* ---------- Terminal ---------- */

static void put_val(int row, int col, const char *s)
{
    CUP(row, col);
    /* %-30s per cancellare eventuali residui di valori precedenti piÃ¹ lunghi */
    printf("%-30s", s);
}

/* Color helpers */
static const char *rpm_color(long rpm) {
    if (rpm < 1200) return CSI_GREEN;
    if (rpm < 3000) return CSI_YELLOW;
    return CSI_RED;
}
static const char *temp_color(long t) {
    if (t < 50) return CSI_GREEN;
    if (t < 70) return CSI_YELLOW;
    return CSI_RED;
}
static const char *mode_color(const char *m) {
    if (strcmp(m, "auto") == 0) return CSI_GREEN;
    if (strcmp(m, "fixed") == 0) return CSI_YELLOW;
    if (strcmp(m, "curve") == 0) return CSI_CYAN;
    return CSI_RESET;
}
static const char *power_color(const char *m) {
    if (strcmp(m, "quiet") == 0) return CSI_GREEN;
    if (strcmp(m, "balanced") == 0) return CSI_YELLOW;
    if (strcmp(m, "performance") == 0) return CSI_RED;
    return CSI_RESET;
}
static const char *batt_color(long cap) {
    if (cap < 20) return CSI_RED;
    if (cap < 50) return CSI_YELLOW;
    return CSI_GREEN;
}

/* ---------- Layout (dynamic, based on fan_count) ---------- */
#define BLOCK_W 40
#define VAL_OFF 20
#define BLOCK_H 6

#define R_TITLE 0
#define R_SPEED 1
#define R_LEVEL 2
#define R_RU    3
#define R_RD    4

typedef struct { int row, col; } Pos;
static Pos pos_fan_mode[MAX_FANS];
static Pos pos_fan_rpm[MAX_FANS];
static Pos pos_fan_level[MAX_FANS];
static Pos pos_fan_ru[MAX_FANS];
static Pos pos_fan_rd[MAX_FANS];
static Pos pos_temp, pos_tmin, pos_tmax;
static Pos pos_power_mode, pos_power_limit, pos_power_apu;
static Pos pos_batt_cap, pos_batt_status;

static void compute_positions(int fan_count)
{
    int max_cols = term_cols / BLOCK_W;
    if (max_cols < 1) max_cols = 1;
    int usable = term_rows - 4;
    int blocks_per_col = usable / BLOCK_H;
    if (blocks_per_col < 1) blocks_per_col = 1;

    int row = 2, col = 0;
    /* Fan blocks */
    for (int i = 1; i <= fan_count; i++) {
        pos_fan_mode[i] = (Pos){row, col * BLOCK_W + VAL_OFF};
        pos_fan_rpm[i]  = (Pos){row + 1, col * BLOCK_W + VAL_OFF};
        pos_fan_level[i]= (Pos){row + 2, col * BLOCK_W + VAL_OFF};
        pos_fan_ru[i]   = (Pos){row + 3, col * BLOCK_W + VAL_OFF};
        pos_fan_rd[i]   = (Pos){row + 4, col * BLOCK_W + VAL_OFF};
        row += BLOCK_H;
        if (row + BLOCK_H > usable + 2) { col++; row = 2; }
    }

    /* Temperature block */
    if (row + BLOCK_H > usable + 2) { col++; row = 2; }
    pos_temp  = (Pos){row + 1, col * BLOCK_W + VAL_OFF};
    pos_tmin  = (Pos){row + 2, col * BLOCK_W + VAL_OFF};
    pos_tmax  = (Pos){row + 3, col * BLOCK_W + VAL_OFF};
    row += BLOCK_H;
    if (row + BLOCK_H > usable + 2) { col++; row = 2; }
    /* Power block: mode, limit, actual */
    pos_power_mode  = (Pos){row + 1, col * BLOCK_W + VAL_OFF};
    pos_power_limit = (Pos){row + 2, col * BLOCK_W + VAL_OFF};
    pos_power_apu   = (Pos){row + 3, col * BLOCK_W + VAL_OFF};
    row += BLOCK_H;
    if (row + BLOCK_H > usable + 2) { col++; row = 2; }
    /* Battery block (Z13 only, alla fine per non lasciare spazio vuoto su AXB35) */
    pos_batt_cap    = (Pos){row + 1, col * BLOCK_W + VAL_OFF};
    pos_batt_status = (Pos){row + 2, col * BLOCK_W + VAL_OFF};
}

/* ---------- Labels ---------- */
static void draw_labels(const D *d, int fan_count)
{
    char dim[128];
    int ims = (int)(interval * 1000);

    CUP(1, 1);
    /* Read DMI product name for title */
    FILE *f_title = fopen("/sys/class/dmi/id/product_name", "r");
    char model[64] = "";
    if (f_title) {
        fgets(model, sizeof(model), f_title);
        char *nl = strchr(model, '\n'); if (nl) *nl = 0;
        fclose(f_title);
    }
    if (!model[0]) strncpy(model, platform_name, sizeof(model) - 1);
    printf("%sSystem Monitor [%s]%s", CSI_BOLD CSI_MAGENTA, model, CSI_RESET);
    snprintf(dim, sizeof(dim), "%s[i:%dms | t:%dx%d]%s",
             CSI_CYAN, ims, term_cols, term_rows, CSI_RESET);
    int dp = term_cols - (int)strlen(dim);
    if (dp < 1) dp = 1;
    CUP(1, dp);
    printf("%s", dim);

    /* Fan labels */
    for (int i = 1; i <= fan_count; i++) {
        int col = pos_fan_mode[i].col - VAL_OFF;
        CUP(pos_fan_mode[i].row, col);
        if (fan_count == 3)
            printf("%s%s Fan %d%s", CSI_BOLD, (i == 3) ? "System" : "APU", i, CSI_RESET);
        else
            printf("%sFan %d%s", CSI_BOLD, i, CSI_RESET);

        CUP(pos_fan_rpm[i].row, col); printf("  Speed: ");

        int show_level = (d->level[i] >= 0);
        int show_ru = (d->ru[i][0] != 0);
        int show_rd = (d->rd[i][0] != 0);

        if (show_level) { CUP(pos_fan_level[i].row, col); printf("  Level: "); }
        else { CUP(pos_fan_level[i].row, col); printf("                        "); }
        if (show_ru) {
            CUP(pos_fan_ru[i].row, col);
            printf("%s", platform_fan_count == 2 ?
                   "  Temp/PWM Curve: " : "  Ramp Up Curve: ");
        }
        else { CUP(pos_fan_ru[i].row, col);    printf("                            "); }
        if (show_rd)    { CUP(pos_fan_rd[i].row, col);    printf("  Ramp Down Curve: "); }
        else { CUP(pos_fan_rd[i].row, col);    printf("                              "); }
    }

    /* Temperature block */
    int col = pos_temp.col - VAL_OFF;
    CUP(pos_temp.row - 1, col); printf("%sTemperature%s", CSI_BOLD, CSI_RESET);
    CUP(pos_temp.row, col);     printf("  Current: ");
    if (d->tmin >= 0) { CUP(pos_tmin.row, col); printf("  Min: "); }
    else { CUP(pos_tmin.row, col); printf("                      "); }
    if (d->tmax >= 0) { CUP(pos_tmax.row, col); printf("  Max: "); }
    else { CUP(pos_tmax.row, col); printf("                      "); }

    /* Power block */
    col = pos_power_mode.col - VAL_OFF;
    CUP(pos_power_mode.row - 1, col); printf("%sPower%s", CSI_BOLD, CSI_RESET);
    CUP(pos_power_mode.row, col);  printf("  Mode: ");
    CUP(pos_power_limit.row, col); printf("  Limit: ");
    CUP(pos_power_apu.row, col);   printf("  Power: ");

    /* Battery (only when battery sensor exists, alla fine per non lasciare buchi) */
    if (d->battery_capacity > 0) {
        col = pos_batt_cap.col - VAL_OFF;
        CUP(pos_batt_cap.row - 1, col); printf("%sBattery%s", CSI_BOLD, CSI_RESET);
        CUP(pos_batt_cap.row, col);     printf("  Capacity: ");
        CUP(pos_batt_status.row, col);  printf("  Status: ");
    } else {
        col = pos_batt_cap.col - VAL_OFF;
        CUP(pos_batt_cap.row - 1, col); printf("                             ");
        CUP(pos_batt_cap.row, col);     printf("                      ");
        CUP(pos_batt_status.row, col);  printf("                      ");
    }

    /* Footer */
    CUP(term_rows, 1);
    printf("%s%s%sPress Ctrl+C to exit%s",
           CSI_BOLD, CSI_BLUE,
           control_mode ? "Temperature policy active | " : "", CSI_RESET);
    fflush(stdout);
}

/* ---------- Values ---------- */
static void draw_values(const D *d, int fan_count)
{
    char buf[256];

    for (int i = 1; i <= fan_count; i++) {
        snprintf(buf, sizeof(buf), "[%s%s%s]", mode_color(d->mode[i]), d->mode[i], CSI_RESET);
        put_val(pos_fan_mode[i].row, pos_fan_mode[i].col, buf);
        snprintf(buf, sizeof(buf), "%s%ld%s RPM", rpm_color(d->rpm[i]), d->rpm[i], CSI_RESET);
        put_val(pos_fan_rpm[i].row, pos_fan_rpm[i].col, buf);
        if (d->level[i] >= 0) {
            if (platform_fan_count == 2 && d->pwm_percent[i] >= 0)
                snprintf(buf, sizeof(buf), "%ld (~%ld%% PWM)",
                         d->level[i], d->pwm_percent[i]);
            else
                snprintf(buf, sizeof(buf), "%ld", d->level[i]);
            put_val(pos_fan_level[i].row, pos_fan_level[i].col, buf);
        }
        if (d->ru[i][0]) put_val(pos_fan_ru[i].row, pos_fan_ru[i].col, d->ru[i]);
        if (d->rd[i][0]) put_val(pos_fan_rd[i].row, pos_fan_rd[i].col, d->rd[i]);
    }

    /* Temperature */
    snprintf(buf, sizeof(buf), "%s%ld%s \302\260C", temp_color(d->cpu_ec), d->cpu_ec, CSI_RESET);
    put_val(pos_temp.row, pos_temp.col, buf);
    if (d->tmin >= 0) {
        snprintf(buf, sizeof(buf), "%ld \302\260C", d->tmin);
        put_val(pos_tmin.row, pos_tmin.col, buf);
    }
    if (d->tmax >= 0) {
        snprintf(buf, sizeof(buf), "%ld \302\260C", d->tmax);
        put_val(pos_tmax.row, pos_tmax.col, buf);
    }

    /* Power block */
    /* Power Mode (colorato in base alla modalità) */
    snprintf(buf, sizeof(buf), "%s%s%s",
             power_color(d->apu_mode[0] ? d->apu_mode : "unknown"),
             d->apu_mode[0] ? d->apu_mode : "unknown", CSI_RESET);
    put_val(pos_power_mode.row, pos_power_mode.col, buf);

    /* Power Limit (TDP) - colorato in base ai watt */
    if (d->tdp_watts > 0) {
        const char *wcolor = CSI_YELLOW;
        if (d->tdp_watts <= 65) wcolor = CSI_GREEN;
        else if (d->tdp_watts <= 85) wcolor = CSI_YELLOW;
        else wcolor = CSI_RED;
        if (d->expected_tdp_watts > 0 &&
            d->tdp_watts != d->expected_tdp_watts) {
            snprintf(buf, sizeof(buf), "%s%ld W (expected %ld W)%s",
                     CSI_RED, d->tdp_watts, d->expected_tdp_watts, CSI_RESET);
        } else {
            snprintf(buf, sizeof(buf), "%s%ld W%s", wcolor,
                     d->tdp_watts, CSI_RESET);
        }
        put_val(pos_power_limit.row, pos_power_limit.col, buf);
    } else {
        put_val(pos_power_limit.row, pos_power_limit.col, "N/A");
    }

    /* Actual Power (consumo reale in W) - colorato in base ai watt */
    if (d->gpu_power_uw > 0) {
        double watts = d->gpu_power_uw / 1000000.0;
        const char *wcolor = CSI_GREEN;
        if (watts > 50) wcolor = CSI_YELLOW;
        if (watts > 80) wcolor = CSI_RED;
        snprintf(buf, sizeof(buf), "%s%.2f W%s", wcolor, watts, CSI_RESET);
        put_val(pos_power_apu.row, pos_power_apu.col, buf);
    } else {
        put_val(pos_power_apu.row, pos_power_apu.col, "N/A");
    }

    /* Battery (when available, alla fine) */
    if (d->battery_capacity > 0) {
        snprintf(buf, sizeof(buf), "%s%ld%%%s", batt_color(d->battery_capacity), d->battery_capacity, CSI_RESET);
        put_val(pos_batt_cap.row, pos_batt_cap.col, buf);
        put_val(pos_batt_status.row, pos_batt_status.col, d->battery_status[0] ? d->battery_status : "N/A");
    }

    fflush(stdout);
}

/* ---------- Main ---------- */

static void usage_mon(const char *prog)
{
    fprintf(stderr,
            "Usage: %s [OPTIONS]\n"
            "  -a          apply and enforce the temperature policy (root)\n"
            "  -i SECONDS  interval (0.3-10)\n"
            "  -j          JSON output\n"
            "  -s <path>   save snapshot\n"
            "  -h          help\n", prog);
}

int main(int argc, char **argv)
{
    int json_mode = 0;
    const char *snapshot_path = NULL;
    int opt;
    while ((opt = getopt(argc, argv, "ai:js:h")) != -1) {
        switch (opt) {
            case 'a': control_mode = 1; break;
            case 'i': interval = atof(optarg); if (interval < 0.3 || interval > 10) return 1; break;
            case 'j': json_mode = 1; break;
            case 's': snapshot_path = optarg; break;
            case 'h': usage_mon(argv[0]); return 0;
            default: usage_mon(argv[0]); return 1;
        }
    }

    /* Detect platform */
    int plat = detect_platform();
    if (plat < 0) {
        fprintf(stderr, "Unknown platform — cannot determine hardware\n");
        return 1;
    }

Platform ops[2] = {
        { "AXB35", 3, axb35_fetch, axb35_print_json },
        { "Z13",   2, z13_fetch,   z13_print_json   }
    };
    Platform *p = &ops[plat];
    platform_fan_count = p->fan_count;
    platform_name = p->name;

    if (control_mode) {
        if (geteuid() != 0) {
            fprintf(stderr, "The temperature policy requires root privileges.\n");
            return 1;
        }
        int result = plat == 0 ? axb35_apply_temperature_policy() :
                                 z13_apply_temperature_policy();
        if (result != 0) {
            fprintf(stderr, "Failed to apply the temperature policy.\n");
            return 1;
        }
    }

    if (json_mode) {
        p->print_json();
        return 0;
    }
    if (snapshot_path) {
        /* TODO: save snapshot */
        fprintf(stderr, "Snapshot not implemented yet\n");
        return 1;
    }

    signal(SIGINT, handle_sigint);
    signal(SIGTERM, handle_sigint);
    signal(SIGWINCH, SIG_IGN);

    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
        term_rows = ws.ws_row;
        term_cols = ws.ws_col;
    }

    /* Clear screen to remove leftover shell characters */
    printf("\033[2J\033[H");
    printf("\033[?25l");
    fflush(stdout);

    D d, prev;
    memset(&prev, 0, sizeof(prev));
    p->fetch(&d);
    compute_positions(p->fan_count);
    draw_labels(&d, p->fan_count);

    int exit_status = 0;
    while (running) {
        if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
            term_rows = ws.ws_row;
            term_cols = ws.ws_col;
            compute_positions(p->fan_count);
            draw_labels(&d, p->fan_count);
        }

        p->fetch(&d);

        if (control_mode && plat == 1 && d.expected_tdp_watts > 0 &&
            d.tdp_watts != d.expected_tdp_watts) {
            if (z13_sync_profile_power_limits() != 0) {
                exit_status = 1;
                break;
            }
            p->fetch(&d);
        }

        /* Detect conditional label changes */
        int needs_redraw = 0;
        for (int i = 1; i <= p->fan_count && !needs_redraw; i++) {
            int cur_l = (d.level[i] >= 0);
            int prv_l = (prev.level[i] >= 0);
            if (cur_l != prv_l) needs_redraw = 1;
            int cur_ru = (d.ru[i][0] != 0);
            int prv_ru = (prev.ru[i][0] != 0);
            if (cur_ru != prv_ru) needs_redraw = 1;
            int cur_rd = (d.rd[i][0] != 0);
            int prv_rd = (prev.rd[i][0] != 0);
            if (cur_rd != prv_rd) needs_redraw = 1;
        }
        if (needs_redraw) draw_labels(&d, p->fan_count);

        draw_values(&d, p->fan_count);
        memcpy(&prev, &d, sizeof(D));

        struct timespec ts;
        ts.tv_sec = (time_t)interval;
        ts.tv_nsec = (long)((interval - (double)ts.tv_sec) * 1e9);
        nanosleep(&ts, NULL);
    }

    printf("\033[?25h\033[2J\033[H");
    printf("Monitor terminated.\n");
    return exit_status;
}
