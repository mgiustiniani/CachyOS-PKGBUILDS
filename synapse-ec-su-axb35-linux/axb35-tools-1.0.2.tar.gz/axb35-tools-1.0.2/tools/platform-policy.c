#define _POSIX_C_SOURCE 200809L
#include "platform-policy.h"
#include "sysfs-helpers.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

#define Z13_CURVE_POINTS 8
#define Z13_ASUS_WMI "/sys/devices/platform/asus-nb-wmi"

static const int Z13_FAN1_CURVE[Z13_CURVE_POINTS * 2] = {
    45, 20, 55, 25, 60, 40, 70, 60,
    80, 70, 83, 80, 95, 100, 95, 100
};

static const int Z13_FAN2_CURVE[Z13_CURVE_POINTS * 2] = {
    45, 25, 55, 30, 60, 45, 70, 65,
    80, 75, 83, 85, 95, 100, 95, 100
};

static const int AXB35_RAMPUP[5] = {60, 70, 83, 95, 97};
static const int AXB35_RAMPDOWN[5] = {50, 60, 80, 94, 96};

long z13_profile_power_limit(const char *profile)
{
    if (strcmp(profile, "quiet") == 0)
        return 40;
    if (strcmp(profile, "balanced") == 0)
        return 52;
    if (strcmp(profile, "performance") == 0)
        return 70;
    return -1;
}

int z13_sync_profile_power_limits(void)
{
    static const char *limits[] = {
        "/ppt_fppt",
        "/ppt_pl1_spl",
        "/ppt_pl2_sppt",
        "/ppt_apu_sppt",
        "/ppt_platform_sppt",
    };
    char profile[64];
    char value[16];
    int failed = 0;

    if (sysfs_read("/sys/firmware/acpi/platform_profile", profile,
                   sizeof(profile)) != 0)
        return 1;

    long watts = z13_profile_power_limit(profile);
    if (watts < 0) {
        fprintf(stderr, "Unsupported platform profile: %s\n", profile);
        return 1;
    }

    snprintf(value, sizeof(value), "%ld", watts);
    for (size_t i = 0; i < sizeof(limits) / sizeof(limits[0]); i++)
        failed |= sysfs_write_platform(Z13_ASUS_WMI, limits[i], value) != 0;

    return failed ? 1 : 0;
}

int z13_estimate_fan_pwm_percent(int fan, long temp_c)
{
    const char *base = get_hwmon_path("asus_custom_fan_curve");
    long temps[Z13_CURVE_POINTS];
    long pwms[Z13_CURVE_POINTS];
    char path[256];

    if (!base || fan < 1 || fan > 2)
        return -1;

    for (int point = 0; point < Z13_CURVE_POINTS; point++) {
        snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp",
                 base, fan, point + 1);
        temps[point] = sysfs_read_long(path);
        snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm",
                 base, fan, point + 1);
        pwms[point] = sysfs_read_long(path);
        if (temps[point] < 0 || pwms[point] < 0)
            return -1;
    }

    long pwm = pwms[0];
    if (temp_c >= temps[Z13_CURVE_POINTS - 1]) {
        pwm = pwms[Z13_CURVE_POINTS - 1];
    } else if (temp_c > temps[0]) {
        for (int point = 1; point < Z13_CURVE_POINTS; point++) {
            if (temp_c <= temps[point]) {
                long span = temps[point] - temps[point - 1];
                if (span > 0) {
                    pwm = pwms[point - 1] +
                          (temp_c - temps[point - 1]) *
                          (pwms[point] - pwms[point - 1]) / span;
                } else {
                    pwm = pwms[point];
                }
                break;
            }
        }
    }

    return (int)((pwm * 100 + 127) / 255);
}

int z13_normalized_fan_level(int pwm_percent)
{
    if (pwm_percent < 0)
        return -1;
    if (pwm_percent == 0)
        return 0;
    int level = (pwm_percent + 19) / 20;
    return level > 5 ? 5 : level;
}

int z13_apply_temperature_policy(void)
{
    const char *custom_base = get_hwmon_path("asus_custom_fan_curve");
    const char *asus_base = get_hwmon_path("asus");
    char path[256];
    char value[32];
    int failed = 0;

    if (!custom_base || !asus_base) {
        fprintf(stderr, "required ASUS fan hwmon interface not found\n");
        return 1;
    }

    /* The ASUS driver requires fan 2 first and curve points in reverse order. */
    for (int fan = 2; fan >= 1; fan--) {
        const int *curve = fan == 1 ? Z13_FAN1_CURVE : Z13_FAN2_CURVE;

        for (int point = Z13_CURVE_POINTS - 1; point >= 0; point--) {
            int temp = curve[point * 2];
            int percent = curve[point * 2 + 1];
            int pwm = (percent * 255 + 50) / 100;

            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_temp",
                     custom_base, fan, point + 1);
            snprintf(value, sizeof(value), "%d", temp);
            failed |= sysfs_write(path, value) != 0;

            snprintf(path, sizeof(path), "%s/pwm%d_auto_point%d_pwm",
                     custom_base, fan, point + 1);
            snprintf(value, sizeof(value), "%d", pwm);
            failed |= sysfs_write(path, value) != 0;

            struct timespec delay = {0, 100000000};
            nanosleep(&delay, NULL);
        }
    }

    /* Enable fan 1 first: enabling fan 1 can reset fan 2 on this driver. */
    for (int fan = 1; fan <= 2; fan++) {
        snprintf(path, sizeof(path), "%s/pwm%d_enable", custom_base, fan);
        failed |= sysfs_write(path, "2") != 0;
        snprintf(path, sizeof(path), "%s/pwm%d_enable", asus_base, fan);
        failed |= sysfs_write(path, "2") != 0;
    }

    failed |= z13_sync_profile_power_limits() != 0;
    return failed ? 1 : 0;
}

int axb35_apply_temperature_policy(void)
{
    char path[256];
    char rampup[64];
    char rampdown[64];
    int failed = 0;

    snprintf(rampup, sizeof(rampup), "%d,%d,%d,%d,%d",
             AXB35_RAMPUP[0], AXB35_RAMPUP[1], AXB35_RAMPUP[2],
             AXB35_RAMPUP[3], AXB35_RAMPUP[4]);
    snprintf(rampdown, sizeof(rampdown), "%d,%d,%d,%d,%d",
             AXB35_RAMPDOWN[0], AXB35_RAMPDOWN[1], AXB35_RAMPDOWN[2],
             AXB35_RAMPDOWN[3], AXB35_RAMPDOWN[4]);

    for (int fan = 1; fan <= 3; fan++) {
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/mode", fan);
        failed |= sysfs_write(path, "curve") != 0;
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampup_curve", fan);
        failed |= sysfs_write(path, rampup) != 0;
        snprintf(path, sizeof(path), AXB35_PATH "/fan%d/rampdown_curve", fan);
        failed |= sysfs_write(path, rampdown) != 0;
    }

    return failed ? 1 : 0;
}
