#ifndef PLATFORM_POLICY_H
#define PLATFORM_POLICY_H

int axb35_apply_temperature_policy(void);
int z13_apply_temperature_policy(void);
int z13_sync_profile_power_limits(void);
long z13_profile_power_limit(const char *profile);
int z13_estimate_fan_pwm_percent(int fan, long temp_c);
int z13_normalized_fan_level(int pwm_percent);

#endif
