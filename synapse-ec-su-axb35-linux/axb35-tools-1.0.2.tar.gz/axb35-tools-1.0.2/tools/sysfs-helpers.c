#include "sysfs-helpers.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include <dirent.h>

/* Cache for hwmon paths */
#define MAX_CACHED 8
static const char *cached_names[MAX_CACHED];
static char cached_paths[MAX_CACHED][128];
static int cached_count = 0;

/* Build a sysfs path under a hwmon into a static buffer (thread-unsafe, ok for CLI) */
static const char *build_hwmon_path(const char *hwmon_name, const char *suffix)
{
    static char buf[256];
    const char *base = get_hwmon_path(hwmon_name);
    if (!base) return NULL;
    snprintf(buf, sizeof(buf), "%s%s", base, suffix);
    return buf;
}

/* Read a sysfs value under a named hwmon */
long sysfs_read_hwmon_long(const char *hwmon_name, const char *suffix)
{
    const char *path = build_hwmon_path(hwmon_name, suffix);
    if (!path) return -1;
    return sysfs_read_long(path);
}

/* Write to a sysfs file under a named hwmon */
int sysfs_write_hwmon(const char *hwmon_name, const char *suffix, const char *str)
{
    const char *path = build_hwmon_path(hwmon_name, suffix);
    if (!path) return -1;
    return sysfs_write(path, str);
}

/* Read a sysfs value under a platform device base path */
long sysfs_read_platform_long(const char *base_path, const char *suffix)
{
    char buf[256];
    snprintf(buf, sizeof(buf), "%s%s", base_path, suffix);
    return sysfs_read_long(buf);
}

/* Write to a platform device sysfs */
int sysfs_write_platform(const char *base_path, const char *suffix, const char *str)
{
    char buf[256];
    snprintf(buf, sizeof(buf), "%s%s", base_path, suffix);
    return sysfs_write(buf, str);
}

/* Find a hwmon by name: scan sysfs directory */
const char *find_hwmon_by_name(const char *name)
{
    static char result[512];
    DIR *dir = opendir("/sys/class/hwmon");
    if (!dir) return NULL;

    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL) {
        if (ent->d_name[0] != 'h') continue;
        char path[512];
        snprintf(path, sizeof(path), "/sys/class/hwmon/%s/name", ent->d_name);
        FILE *fp = fopen(path, "r");
        if (!fp) continue;
        char buf[64];
        size_t n = fread(buf, 1, sizeof(buf) - 1, fp);
        buf[n] = 0;
        /* Trim newline */
        char *nl = strchr(buf, '\n');
        if (nl) *nl = 0;
        fclose(fp);
        if (strcmp(buf, name) == 0) {
            snprintf(result, sizeof(result), "/sys/class/hwmon/%s", ent->d_name);
            /* NOTE: result buffer is 128 bytes; d_name max is 255; but hwmon paths are short */
            closedir(dir);
            return result;
        }
    }
    closedir(dir);
    return NULL;
}

/* Get cached hwmon path for a known name */
const char *get_hwmon_path(const char *name)
{
    /* Check cache first */
    for (int i = 0; i < cached_count; i++) {
        if (strcmp(cached_names[i], name) == 0)
            return cached_paths[i];
    }
    /* Find and cache */
    const char *found = find_hwmon_by_name(name);
    if (!found) return NULL;
    if (cached_count < MAX_CACHED) {
        cached_names[cached_count] = strdup(name);
        strncpy(cached_paths[cached_count], found, sizeof(cached_paths[cached_count]) - 1);
        cached_paths[cached_count][sizeof(cached_paths[cached_count]) - 1] = 0;
        cached_count++;
    }
    return found;
}

int sysfs_read(const char *path, char *buf, size_t bufsz)
{
    FILE *fp;
    if (!buf || bufsz == 0)
        return -1;

    buf[0] = '\0';
    fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "sysfs: can't open '%s': %s\n", path, strerror(errno));
        return -1;
    }

    size_t n = fread(buf, 1, bufsz - 1, fp);
    fclose(fp);

    /* Strip trailing whitespace / newline */
    while (n > 0 && isspace((unsigned char)buf[n - 1]))
        n--;
    buf[n] = '\0';

    return 0;
}

int sysfs_write(const char *path, const char *str)
{
    FILE *fp;
    fp = fopen(path, "w");
    if (!fp) {
        fprintf(stderr, "sysfs: can't open '%s' for writing: %s\n",
                path, strerror(errno));
        return -1;
    }

    if (fputs(str, fp) == EOF || fflush(fp) != 0) {
        fprintf(stderr, "sysfs: failed to write to '%s': %s\n",
                path, strerror(errno));
        fclose(fp);
        return -1;
    }

    fclose(fp);
    return 0;
}

long sysfs_read_long(const char *path)
{
    char buf[128];
    if (sysfs_read(path, buf, sizeof(buf)) != 0)
        return -1;
    return atol(buf);
}

long sysfs_read_slong(const char *path)
{
    char buf[128];
    if (sysfs_read(path, buf, sizeof(buf)) != 0)
        return -1;
    return atol(buf);
}

void fmt_bytes(char *buf, size_t bufsz, unsigned long long bytes)
{
    /* We work with pages from /proc/meminfo; convert to human-readable */
    static const char *units[] = {"B", "KiB", "MiB", "GiB", "TiB"};
    int i;
    double val = (double)bytes;

    /* Convert to bytes if given in KiB (meminfo is in kB) */
    /* We'll assume input is in bytes unless otherwise noted */
    for (i = 0; i < 5 && val >= 1024.0; i++)
        val /= 1024.0;

    if (i == 0)
        snprintf(buf, bufsz, "%.0f %s", val, units[i]);
    else
        snprintf(buf, bufsz, "%.1f %s", val, units[i]);
}

void fmt_power(char *buf, size_t bufsz, unsigned long long microwatts)
{
    double watts = (double)microwatts / 1000000.0;
    if (watts >= 1000.0)
        snprintf(buf, bufsz, "%.2f kW", watts / 1000.0);
    else
        snprintf(buf, bufsz, "%.2f W", watts);
}

void fmt_temp(char *buf, size_t bufsz, long microdeg)
{
    double deg = (double)microdeg / 1000.0;
    snprintf(buf, bufsz, "%.1f °C", deg);
}
