#ifndef AXB35_SYSFS_HELPERS_H
#define AXB35_SYSFS_HELPERS_H

#include <stddef.h>

/* Sysfs base paths */
#define AXB35_PATH      "/sys/class/ec_su_axb35"
#define DRM_PATH        "/sys/class/drm/card1/device"
/* Legacy hardcoded hwmon paths — deprecated, use get_hwmon_path() instead */
#define HWMON_GPU_PATH  "/sys/class/hwmon/hwmon2"
#define HWMON_CPU_PATH  "/sys/class/hwmon/hwmon3"

/* Dynamic hwmon lookup: returns path like "/sys/class/hwmon/hwmonX" or NULL */
const char *find_hwmon_by_name(const char *name);

/* Convenience: get hwmon path for a known name, caching it */
const char *get_hwmon_path(const char *name);

/* Read a sysfs file under a hwmon: builds path from hwmon_name + suffix */
long sysfs_read_hwmon_long(const char *hwmon_name, const char *suffix);

/* Write to a sysfs file under a hwmon */
int sysfs_write_hwmon(const char *hwmon_name, const char *suffix, const char *str);

/* Read a sysfs file under a platform device base path */
long sysfs_read_platform_long(const char *base_path, const char *suffix);

/* Write to a platform device sysfs */
int sysfs_write_platform(const char *base_path, const char *suffix, const char *str);

/* Read a sysfs file under a hwmon: builds path from hwmon_name + suffix */
long sysfs_read_hwmon_long(const char *hwmon_name, const char *suffix);

/* Write to a sysfs file under a hwmon: builds path from hwmon_name + suffix */
int sysfs_write_hwmon(const char *hwmon_name, const char *suffix, const char *str);

/* Read a sysfs file under a platform device: builds path from base + suffix */
long sysfs_read_platform_long(const char *base_path, const char *suffix);

/* Write to a platform device sysfs */
int sysfs_write_platform(const char *base_path, const char *suffix, const char *str);

/* Fan indices (can be overridden per-platform) */
#ifndef FAN_COUNT
#define FAN_COUNT 3
#endif

/* Power modes */
#define APU_MODE_QUIET       "quiet"
#define APU_MODE_BALANCED    "balanced"
#define APU_MODE_PERFORMANCE "performance"

/* Fan modes */
#define FAN_MODE_AUTO  "auto"
#define FAN_MODE_FIXED "fixed"
#define FAN_MODE_CURVE "curve"

/* Read a sysfs file into a fixed buffer; returns 0 on success, -1 on error */
int sysfs_read(const char *path, char *buf, size_t bufsz);

/* Write a string to a sysfs file; returns 0 on success, -1 on error */
int sysfs_write(const char *path, const char *str);

/* Convenience: read a sysfs value as unsigned long */
long sysfs_read_long(const char *path);

/* Convenience: read a sysfs value as signed long (for negative-capable) */
long sysfs_read_slong(const char *path);

/* Format bytes into human-readable (KiB/MiB/GiB) */
void fmt_bytes(char *buf, size_t bufsz, unsigned long long bytes);

/* Format microwatts into watts */
void fmt_power(char *buf, size_t bufsz, unsigned long long microwatts);

/* Format microdegrees into Celsius */
void fmt_temp(char *buf, size_t bufsz, long microdeg);

#endif
